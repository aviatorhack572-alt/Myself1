<?php
require_once "config.php";

if (isset($_GET['hub_mode']) && $_GET['hub_mode'] == 'subscribe') {
    if (isset($_GET['hub_challenge'])) { echo $_GET['hub_challenge']; exit; }
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);
file_put_contents("log.txt", date('Y-m-d H:i:s')." ".$input."\n\n", FILE_APPEND);

if (!$data || !isset($data['entry'][0]['changes'][0]['value'])) { http_response_code(200); exit; }
$value = $data['entry'][0]['changes'][0]['value'];

// Status - blue tick ke liye - tumhara purana code
if (isset($value['statuses'][0])) {
    $wamid = $value['statuses'][0]['id'] ?? '';
    $status = $value['statuses'][0]['status'] ?? '';
    if ($wamid && $status) {
        $conn->query("UPDATE messages SET status='".$conn->real_escape_string($status)."' WHERE wamid='".$conn->real_escape_string($wamid)."' LIMIT 1");
    }
    http_response_code(200); exit;
}

if (!isset($value['messages'][0])) { http_response_code(200); exit; }

$phone_id_meta = $value['metadata']['phone_number_id'] ?? '';
$msg = $value['messages'][0];
$wa_id = $msg['from'] ?? '';
$type = $msg['type'] ?? 'text';
$wamid = $msg['id'] ?? '';

// ===== AUTO BOT TABLES AUTO CREATE =====
$conn->set_charset("utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS auto_bots (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, welcome_message TEXT, is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_phone (phone_number_id))");
$conn->query("CREATE TABLE IF NOT EXISTS auto_menus (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, parent_id INT NULL, title VARCHAR(190) NOT NULL, button_id VARCHAR(100) NOT NULL, reply_text TEXT NULL, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
$conn->query("CREATE TABLE IF NOT EXISTS auto_user_state (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, wa_id VARCHAR(30) NOT NULL, error_count INT DEFAULT 0, is_handover TINYINT(1) DEFAULT 0, last_menu_id INT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, UNIQUE KEY uniq_user (phone_number_id, wa_id))");

// Phone row - tumhara purana code + token ke liye
$q = $conn->query("SELECT * FROM phone_numbers WHERE phone_id = '".$conn->real_escape_string($phone_id_meta)."' LIMIT 1");
$phone_row_id = 1; $own_number = ''; $token_to_use = $ACCESS_TOKEN ?? '';
if ($q && $q->num_rows > 0) { $r = $q->fetch_assoc(); $phone_row_id = $r['id']; $own_number = $r['phone_number']; if(!empty($r['access_token'])) $token_to_use = $r['access_token']; }

// ===== BOT LOGIC HELPERS =====
function wa_send($to, $meta_id, $token, $payload){
    $ver = isset($GLOBALS['GRAPH_API_VERSION']) ? $GLOBALS['GRAPH_API_VERSION'] : 'v23.0';
    $ch = curl_init("https://graph.facebook.com/$ver/$meta_id/messages");
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".$token, "Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $res=curl_exec($ch); curl_close($ch); 
    file_put_contents("log.txt", date('Y-m-d H:i:s')." SEND: ".json_encode($payload)." RES: $res\n\n", FILE_APPEND);
    return $res;
}
function bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $body){
    $body_esc = $conn->real_escape_string($body);
    $conn->query("INSERT INTO messages (phone_number_id,sender_phone,recipient_phone,direction,message_text,message_body,message_type,msg_type,status,created_at) VALUES ('$phone_row_id','".$conn->real_escape_string($own_number)."','".$conn->real_escape_string($wa_id)."','out','$body_esc','$body_esc','text','text','sent',NOW())");
}
function sendMainMenu($conn, $phone_row_id, $meta_id, $token, $wa_id, $own_number, $bot){
    $mains_res = $conn->query("SELECT * FROM auto_menus WHERE phone_number_id=$phone_row_id AND parent_id IS NULL AND is_active=1 ORDER BY sort_order ASC, id ASC");
    $buttons=[]; $rows=[];
    while($r=$mains_res->fetch_assoc()){
        $title = mb_substr($r['title'],0,20);
        $buttons[]=["type"=>"reply","reply"=>["id"=>$r['button_id'],"title"=>$title]];
        $rows[]=["id"=>$r['button_id'],"title"=>mb_substr($r['title'],0,24),"description"=>""];
    }
    if(count($rows)==0) return;
    $welcome = $bot['welcome_message'] ?? "Assalam-o-Alaikum! FastSky me khush aamdeed. Neeche menu select karen:";
    if(count($buttons)<=3){
        $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"interactive","interactive"=>["type"=>"button","body"=>["text"=>$welcome],"action"=>["buttons"=>$buttons]]];
    } else {
        $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"interactive","interactive"=>["type"=>"list","body"=>["text"=>$welcome],"action"=>["button"=>"Select Menu","sections"=>[["title"=>"Main Menu","rows"=>$rows]]]]];
    }
    wa_send($wa_id, $meta_id, $token, $payload);
    bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $welcome." [MAIN MENU]");
    $conn->query("UPDATE auto_user_state SET error_count=0, last_menu_id=NULL WHERE phone_number_id=$phone_row_id AND wa_id='".$conn->real_escape_string($wa_id)."'");
}
function sendSubMenu($conn, $phone_row_id, $meta_id, $token, $wa_id, $own_number, $parent_db_id){
    $parent = $conn->query("SELECT * FROM auto_menus WHERE id=$parent_db_id LIMIT 1")->fetch_assoc();
    if(!$parent) return;
    $subs_res = $conn->query("SELECT * FROM auto_menus WHERE phone_number_id=$phone_row_id AND parent_id=$parent_db_id AND is_active=1 ORDER BY sort_order ASC");
    $buttons=[]; $rows=[];
    while($r=$subs_res->fetch_assoc()){
        $buttons[]=["type"=>"reply","reply"=>["id"=>$r['button_id'],"title"=>mb_substr($r['title'],0,20)]];
        $rows[]=["id"=>$r['button_id'],"title"=>mb_substr($r['title'],0,24)];
    }
    $bodyText = "📁 ".$parent['title']."\nNeeche se select karen:";
    if(count($rows)==0){ // agar sub menu nahi, to direct reply
        $bodyText = $parent['reply_text'] ?? $parent['title'];
        $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"text","text"=>["body"=>$bodyText]];
        wa_send($wa_id, $meta_id, $token, $payload);
        bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $bodyText);
        return;
    }
    if(count($buttons)<=3){
        $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"interactive","interactive"=>["type"=>"button","body"=>["text"=>$bodyText],"action"=>["buttons"=>$buttons]]];
    } else {
        $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"interactive","interactive"=>["type"=>"list","body"=>["text"=>$bodyText],"action"=>["button"=>"Sub Menu","sections"=>[["title"=>$parent['title'],"rows"=>$rows]]]]];
    }
    wa_send($wa_id, $meta_id, $token, $payload);
    bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $bodyText." [SUB MENU]");
}

// ===== BOT CHECK =====
$bot = $conn->query("SELECT * FROM auto_bots WHERE phone_number_id=$phone_row_id LIMIT 1")->fetch_assoc();
$wa_id_esc = $conn->real_escape_string($wa_id);
$us = $conn->query("SELECT * FROM auto_user_state WHERE phone_number_id=$phone_row_id AND wa_id='$wa_id_esc' LIMIT 1")->fetch_assoc();
if(!$us){
    $conn->query("INSERT INTO auto_user_state (phone_number_id, wa_id, error_count, is_handover) VALUES ($phone_row_id, '$wa_id_esc', 0, 0)");
    $us = ['error_count'=>0, 'is_handover'=>0, 'last_menu_id'=>null];
}

// Agar handover hai to bot kuch nahi karega, sirf neeche tumhara purana save wala code chalega
$is_handover = (int)($us['is_handover'] ?? 0);
if($bot && $bot['is_active'] && $is_handover==0){
    $button_id = '';
    $text_for_bot = '';
    if($type=='interactive'){
        if(isset($msg['interactive']['button_reply']['id'])) $button_id = $msg['interactive']['button_reply']['id'];
        if(isset($msg['interactive']['list_reply']['id'])) $button_id = $msg['interactive']['list_reply']['id'];
        $text_for_bot = $msg['interactive']['button_reply']['title'] ?? $msg['interactive']['list_reply']['title'] ?? '';
    } elseif($type=='text'){
        $text_for_bot = $msg['text']['body'] ?? '';
    }

    $should_run_bot = false;
    $lower = strtolower(trim($text_for_bot));

    if($button_id){
        // Button click
        $menu = $conn->query("SELECT * FROM auto_menus WHERE phone_number_id=$phone_row_id AND button_id='".$conn->real_escape_string($button_id)."' AND is_active=1 LIMIT 1")->fetch_assoc();
        if($menu){
            if(is_null($menu['parent_id'])){
                // Main menu -> show sub
                $conn->query("UPDATE auto_user_state SET last_menu_id={$menu['id']}, error_count=0 WHERE phone_number_id=$phone_row_id AND wa_id='$wa_id_esc'");
                sendSubMenu($conn, $phone_row_id, $phone_id_meta, $token_to_use, $wa_id, $own_number, $menu['id']);
            } else {
                // Sub menu -> final reply + phir main menu
                $finalReply = $menu['reply_text'] ?? '';
                if($finalReply){
                    $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"text","text"=>["body"=>$finalReply]];
                    wa_send($wa_id, $phone_id_meta, $token_to_use, $payload);
                    bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $finalReply);
                }
                $conn->query("UPDATE auto_user_state SET error_count=0 WHERE phone_number_id=$phone_row_id AND wa_id='$wa_id_esc'");
                // 1 sec baad main menu dubara
                sleep(1);
                sendMainMenu($conn, $phone_row_id, $phone_id_meta, $token_to_use, $wa_id, $own_number, $bot);
            }
        }
    } else {
        $is_greeting = in_array($lower, ['hi','hello','salam','asalam o alaikum','assalam o alaikum','assalamu alaikum','start','menu','hey']);
        // Pehli bar ya greeting ho to main menu
        if($is_greeting || ((int)$us['error_count']==0 && $us['last_menu_id']==null)){
            sendMainMenu($conn, $phone_row_id, $phone_id_meta, $token_to_use, $wa_id, $own_number, $bot);
        } else if($type=='text' && trim($text_for_bot)!=''){
            // galat message
            $newCount = (int)$us['error_count'] + 1;
            if($newCount < 3){
                $errMsg = "⚠️ براہ مہربانی متعلقہ مینو میں سے مینو سلیکٹ کریں۔";
                $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"text","text"=>["body"=>$errMsg]];
                wa_send($wa_id, $phone_id_meta, $token_to_use, $payload);
                bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $errMsg);
                $conn->query("UPDATE auto_user_state SET error_count=$newCount WHERE phone_number_id=$phone_row_id AND wa_id='$wa_id_esc'");
                sleep(1);
                sendMainMenu($conn, $phone_row_id, $phone_id_meta, $token_to_use, $wa_id, $own_number, $bot);
            } else {
                $handoverMsg = "✅ آپ کی چیٹ لائیو ایجنٹ سے کنیکٹ کر دی گئی ہے۔\n\nبراہ مہربانی تھوڑی دیر انتظار کریں، ہماری سپورٹ ٹیم کا نمائندہ بہت جلد آپ سے رابطہ کرے گا۔ 🙏";
                $payload=["messaging_product"=>"whatsapp","to"=>$wa_id,"type"=>"text","text"=>["body"=>$handoverMsg]];
                wa_send($wa_id, $phone_id_meta, $token_to_use, $payload);
                bot_save_out($conn, $phone_row_id, $wa_id, $own_number, $handoverMsg);
                $conn->query("UPDATE auto_user_state SET is_handover=1, error_count=$newCount WHERE phone_number_id=$phone_row_id AND wa_id='$wa_id_esc'");
            }
        }
    }
}

// ===== TUMHARA PURANA SAVE MESSAGE WALA CODE =====
$message_body = ''; $media_id_db = ''; $media_url_db = ''; $media_filename_db = '';

if ($type == 'text') {
    $message_body = $msg['text']['body'] ?? '';
} elseif ($type == 'interactive') {
    // interactive ke liye bhi save karo
    $message_body = $msg['interactive']['button_reply']['title'] ?? $msg['interactive']['list_reply']['title'] ?? ($msg['interactive']['button_reply']['id'] ?? '');
} else {
    $media_id = ''; $mime_type = '';
    if ($type == 'image' && isset($msg['image']['id'])) {
        $media_id = $msg['image']['id']; $mime_type = $msg['image']['mime_type'] ?? 'image/jpeg';
        $message_body = $msg['image']['caption'] ?? ''; $media_filename_db = 'image.jpg';
    } elseif ($type == 'audio' && isset($msg['audio']['id'])) {
        $media_id = $msg['audio']['id']; $mime_type = $msg['audio']['mime_type'] ?? 'audio/ogg';
        $message_body = ''; $media_filename_db = 'voice_'.time().'.ogg'; $type = 'audio';
    } elseif ($type == 'voice' && isset($msg['voice']['id'])) {
        $media_id = $msg['voice']['id']; $mime_type = $msg['voice']['mime_type'] ?? 'audio/ogg';
        $message_body = ''; $media_filename_db = 'voice_'.time().'.ogg'; $type = 'audio';
    } elseif ($type == 'video' && isset($msg['video']['id'])) {
        $media_id = $msg['video']['id']; $mime_type = $msg['video']['mime_type'] ?? 'video/mp4';
        $message_body = $msg['video']['caption'] ?? ''; $media_filename_db = 'video.mp4';
    } elseif ($type == 'document' && isset($msg['document']['id'])) {
        $media_id = $msg['document']['id']; $mime_type = $msg['document']['mime_type'] ?? '';
        $media_filename_db = $msg['document']['filename'] ?? 'document.pdf'; $message_body = $media_filename_db;
    }

    if (!empty($media_id)) {
        $media_id_db = $media_id;
        if (!empty($token_to_use)) {
            $ver = isset($GRAPH_API_VERSION) ? $GRAPH_API_VERSION : 'v23.0';
            $ch = curl_init("https://graph.facebook.com/$ver/{$media_id}");
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".$token_to_use]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $res = curl_exec($ch); curl_close($ch);
            $j = json_decode($res, true);
            if (isset($j['url'])) {
                $ch2 = curl_init($j['url']);
                curl_setopt($ch2, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".$token_to_use]);
                curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
                $bin = curl_exec($ch2); curl_close($ch2);
                if ($bin) {
                    $ext = 'bin';
                    if (strpos($mime_type,'jpeg')!==false||strpos($mime_type,'jpg')!==false) $ext='jpg';
                    elseif (strpos($mime_type,'png')!==false) $ext='png';
                    elseif (strpos($mime_type,'ogg')!==false) $ext='ogg';
                    elseif (strpos($mime_type,'mp4')!==false) $ext='mp4';
                    elseif (strpos($mime_type,'mp3')!==false) $ext='mp3';
                    $dir = "uploads/media/"; if(!is_dir($dir)) mkdir($dir,0777,true);
                    $fname = time()."_".rand(1000,9999).".".$ext;
                    if(file_put_contents($dir.$fname,$bin)){ $media_url_db = $dir.$fname; }
                }
            }
        }
    }
}

$sql = "INSERT INTO messages (phone_number_id,sender_phone,recipient_phone,direction,message_text,message_body,message_type,msg_type,media_id,media_url,media_filename,wamid,status,created_at) VALUES ('$phone_row_id','".$conn->real_escape_string($wa_id)."','".$conn->real_escape_string($own_number)."','in','".$conn->real_escape_string($message_body)."','".$conn->real_escape_string($message_body)."','".$conn->real_escape_string($type)."','".$conn->real_escape_string($type)."','".$conn->real_escape_string($media_id_db)."','".$conn->real_escape_string($media_url_db)."','".$conn->real_escape_string($media_filename_db)."','".$conn->real_escape_string($wamid)."','delivered',NOW())";
$conn->query($sql);
http_response_code(200);