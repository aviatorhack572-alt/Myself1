<?php
session_start();
require_once "../config.php";

// Set header to return JSON response
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit();
}

$phone_number_id = $_SESSION['phone_number_id'] ?? 1;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['recipient_wa_id'])) {
    $recipient_wa_id = trim($_POST['recipient_wa_id']);
    $message_body = trim($_POST['message'] ?? '');
    
    $stmt_p = $conn->prepare("SELECT phone_id FROM phone_numbers WHERE id = ?");
    $stmt_p->bind_param("i", $phone_number_id);
    $stmt_p->execute();
    $res_p = $stmt_p->get_result();
    
    if ($res_p->num_rows > 0) {
        $p_row = $res_p->fetch_assoc();
        $phone_id = $p_row['phone_id'];

        $media_url_db = '';
        $msg_type = 'text';
        $uploaded_file_path = '';
        $meta_response_log = '';
        $meta_send_log = '';

        // 1. Handle File / Image / Audio Upload Locally
        if (isset($_FILES['media_file']) && $_FILES['media_file']['error'] == 0) {
            $dir = "../uploads/media/";
            if (!is_dir($dir)) {
                mkdir($dir, 0777, true);
            }
            $ext = strtolower(pathinfo($_FILES['media_file']['name'], PATHINFO_EXTENSION));
            $detected_mime = mime_content_type($_FILES['media_file']['tmp_name']);
            
            // Check if it's audio/voice or image
            if (strpos($detected_mime, 'audio/') !== false || strpos($detected_mime, 'video/webm') !== false || in_array($ext, ['mp3', 'ogg', 'wav', 'm4a', 'aac', 'webm', 'bin'])) {
                $msg_type = 'audio'; // We keep internal type as audio
                if (empty($ext) || $ext == 'bin' || $ext == 'webm') {
                    $ext = 'mp3'; // Save as mp3 locally so it plays easily
                }
            } elseif (strpos($detected_mime, 'image/') !== false || in_array($ext, ['jpg', 'jpeg', 'png', 'gif'])) {
                $msg_type = 'image';
            } else {
                $msg_type = 'document';
            }
            
            $fname = $dir . time() . "_" . rand(1000, 9999) . "." . $ext;
            
            if (move_uploaded_file($_FILES['media_file']['tmp_name'], $fname)) {
                $media_url_db = "uploads/media/" . basename($fname);
                $uploaded_file_path = realpath($fname);
                
                if (empty($message_body)) {
                    $message_body = "[" . strtoupper($msg_type) . " Message]";
                }
            }
        }

        // 2. Send via Meta Cloud API
        if (!empty($phone_id) && !empty($ACCESS_TOKEN)) {
            
            if (!empty($uploaded_file_path) && file_exists($uploaded_file_path)) {
                
                $mime_type = mime_content_type($uploaded_file_path);
                
                // If it's audio, we treat it as document/audio safely for Meta API
                if ($msg_type == 'audio') {
                    $mime_type = 'audio/mpeg';
                }
                
                $cfile = new CURLFile($uploaded_file_path, $mime_type, basename($uploaded_file_path));
                $media_upload_url = "https://graph.facebook.com/v20.0/{$phone_id}/media";
                
                $post_fields = [
                    'messaging_product' => 'whatsapp',
                    'file' => $cfile
                ];
                
                $ch_m = curl_init($media_upload_url);
                curl_setopt($ch_m, CURLOPT_HTTPHEADER, ["Authorization: Bearer " . $ACCESS_TOKEN]);
                curl_setopt($ch_m, CURLOPT_POST, true);
                curl_setopt($ch_m, CURLOPT_POSTFIELDS, $post_fields);
                curl_setopt($ch_m, CURLOPT_RETURNTRANSFER, true);
                $m_res = curl_exec($ch_m);
                curl_close($ch_m);
                
                $meta_response_log = $m_res;
                $m_data = json_decode($m_res, true);
                
                if (isset($m_data['id'])) {
                    $meta_media_id = $m_data['id'];
                    $api_url = "https://graph.facebook.com/v20.0/{$phone_id}/messages";
                    
                    if ($msg_type == 'image') {
                        $payload = [
                            "messaging_product" => "whatsapp",
                            "to" => $recipient_wa_id,
                            "type" => "image",
                            "image" => [
                                "id" => $meta_media_id,
                                "caption" => ($message_body !== "[IMAGE Message]") ? $message_body : ""
                            ]
                        ];
                    } elseif ($msg_type == 'audio') {
                        // SMART FIX: Sending audio as a Document to guarantee 100% delivery on WhatsApp without format rejection
                        $payload = [
                            "messaging_product" => "whatsapp",
                            "to" => $recipient_wa_id,
                            "type" => "document",
                            "document" => [
                                "id" => $meta_media_id,
                                "filename" => "Voice_Note.mp3",
                                "caption" => "Voice Message"
                            ]
                        ];
                    } else {
                        $payload = [
                            "messaging_product" => "whatsapp",
                            "to" => $recipient_wa_id,
                            "type" => "document",
                            "document" => [
                                "id" => $meta_media_id,
                                "caption" => $message_body
                            ]
                        ];
                    }
                    
                    $ch = curl_init($api_url);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer " . $ACCESS_TOKEN, "Content-Type: application/json"]);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $meta_send_log = curl_exec($ch);
                    curl_close($ch);
                }
            } else if (!empty($message_body)) {
                // Send Normal Text Message
                $api_url = "https://graph.facebook.com/v20.0/{$phone_id}/messages";
                $payload = [
                    "messaging_product" => "whatsapp",
                    "to" => $recipient_wa_id,
                    "type" => "text",
                    "text" => ["body" => $message_body]
                ];
                
                $ch = curl_init($api_url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer " . $ACCESS_TOKEN, "Content-Type: application/json"]);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $meta_send_log = curl_exec($ch);
                curl_close($ch);
            }
        }

        // 3. Save in Database
        $ins = $conn->prepare("INSERT INTO messages (phone_number_id, sender_phone, message_body, msg_type, media_url, direction, created_at) VALUES (?, ?, ?, ?, ?, 'outbound', NOW())");
        $ins->bind_param("issss", $phone_number_id, $recipient_wa_id, $message_body, $msg_type, $media_url_db);
        $ins->execute();
        $ins->close();

        // 4. Return response
        echo json_encode([
            'status' => 'success', 
            'msg_type' => $msg_type,
            'meta_upload_response' => json_decode($meta_response_log, true),
            'meta_send_response' => json_decode($meta_send_log, true)
        ]);
        exit();
    }
}
echo json_encode(['status' => 'error', 'message' => 'Invalid Request']);
