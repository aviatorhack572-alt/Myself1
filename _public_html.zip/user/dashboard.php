<?php
session_start();
require_once __DIR__ . '/../config.php';
mysqli_report(MYSQLI_REPORT_OFF);
ini_set('display_errors','0');
$GRAPH_VERSION = isset($GRAPH_API_VERSION) && preg_match('/^v\d+\.\d+$/', $GRAPH_API_VERSION) ? $GRAPH_API_VERSION : 'v23.0';
function out_json($d,$s=200){http_response_code($s);header('Content-Type: application/json; charset=utf-8');echo json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function incoming_sql(){return "direction IN ('in','inbound','incoming')";}
function graph_call($url,$token,$method='GET',$fields=null,$multipart=false){
 $ch=curl_init($url); $headers=['Authorization: Bearer '.$token];
 curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_CONNECTTIMEOUT=>20,CURLOPT_TIMEOUT=>90]);
 if($fields!==null){curl_setopt($ch,CURLOPT_POSTFIELDS,$fields); if(!$multipart) $headers[]='Content-Type: application/json';}
 curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
 $body=curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
 return ['ok'=>$body!==false&&$http>=200&&$http<300,'http'=>$http,'data'=>json_decode((string)$body,true)];
}
if(empty($_SESSION['user_id'])||empty($_SESSION['phone_number_id'])){header('Location: login.php');exit;}
$userId=(int)$_SESSION['user_id']; $localPhoneId=(int)$_SESSION['phone_number_id'];
$stmt=$conn->prepare('SELECT u.id,u.phone_number_id AS local_phone_id,p.phone_number,p.phone_id AS meta_phone_id FROM users u JOIN phone_numbers p ON p.id=u.phone_number_id WHERE u.id=? LIMIT 1');
$stmt->bind_param('i',$userId); $stmt->execute(); $userPhone=$stmt->get_result()->fetch_assoc(); $stmt->close();
if(!$userPhone){session_destroy();header('Location: login.php');exit;}
if(empty($_SESSION['dashboard_csrf'])) $_SESSION['dashboard_csrf']=bin2hex(random_bytes(32)); $csrf=$_SESSION['dashboard_csrf'];
$conn->query("CREATE TABLE IF NOT EXISTS blocked_users (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, customer_phone VARCHAR(50) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_block (phone_number_id,customer_phone))");
if(isset($_GET['ajax']) && $_GET['ajax']==='1'){
 $action=$_POST['action']??$_GET['action']??''; $incoming=incoming_sql();
 if($_SERVER['REQUEST_METHOD']==='POST'){ $pt=$_POST['csrf_token']??''; if(!hash_equals($csrf,$pt)) out_json(['ok'=>false,'error'=>'Session expired'],403); }
 if($action==='chats'){
  $sql="SELECT CASE WHEN ".$incoming." THEN sender_phone ELSE recipient_phone END AS customer_phone, MAX(created_at) AS last_at, SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(NULLIF(message_text,''),NULLIF(message_body,''),CONCAT('[',COALESCE(NULLIF(message_type,''),NULLIF(msg_type,''),'media'),']')) ORDER BY created_at DESC SEPARATOR '\n'),'\n',1) AS last_message FROM messages WHERE phone_number_id=? AND hidden_at IS NULL GROUP BY customer_phone ORDER BY last_at DESC LIMIT 300";
  $stmt=$conn->prepare($sql); $stmt->bind_param('i',$localPhoneId); $stmt->execute(); $r=$stmt->get_result(); $chats=[]; while($r&&($row=$r->fetch_assoc())) $chats[]=$row; $stmt->close(); out_json(['ok'=>true,'chats'=>$chats]);
 }
 if($action==='messages'){
  $customer=trim($_GET['customer']??''); $after=(int)($_GET['after']??0);
  $sql="SELECT id,sender_phone,recipient_phone,direction,COALESCE(NULLIF(message_text,''),message_body,'') AS message_text,COALESCE(NULLIF(message_type,''),NULLIF(msg_type,''),'text') AS message_type,media_id,media_url,media_filename,status,wamid,DATE_FORMAT(created_at,'%H:%i') AS time_label FROM messages WHERE phone_number_id=? AND hidden_at IS NULL AND (sender_phone=? OR recipient_phone=?) AND id>? ORDER BY id ASC LIMIT 500";
  $stmt=$conn->prepare($sql); $stmt->bind_param('issi',$localPhoneId,$customer,$customer,$after); $stmt->execute(); $res=$stmt->get_result(); $msgs=[]; while($res&&($rw=$res->fetch_assoc())) $msgs[]=$rw; $stmt->close(); out_json(['ok'=>true,'messages'=>$msgs]);
 }
 if($action==='status_sync'){
  $customer=trim($_GET['customer']??'');
  $sql="SELECT id,status FROM messages WHERE phone_number_id=? AND (sender_phone=? OR recipient_phone=?) AND direction='out' ORDER BY id DESC LIMIT 50";
  $stmt=$conn->prepare($sql); $stmt->bind_param('iss',$localPhoneId,$customer,$customer); $stmt->execute(); $res=$stmt->get_result(); $arr=[]; while($res&&($r=$res->fetch_assoc())) $arr[]=$r; $stmt->close(); out_json(['ok'=>true,'statuses'=>$arr]);
 }
 if($action==='media'){
  $mediaId=trim($_GET['id']??''); if($mediaId===''){http_response_code(404);exit;}
  $meta=graph_call('https://graph.facebook.com/'.$GRAPH_VERSION.'/'.rawurlencode($mediaId),$ACCESS_TOKEN); $mediaUrl=$meta['data']['url']??''; if(!$meta['ok']||!$mediaUrl){http_response_code(502);exit;}
  $ch=curl_init($mediaUrl); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>20,CURLOPT_TIMEOUT=>90,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$ACCESS_TOKEN]]); $bytes=curl_exec($ch); curl_close($ch); if($bytes===false){http_response_code(502);exit;}
  $mime=$meta['data']['mime_type']??'application/octet-stream'; header('Content-Type: '.$mime); header('Cache-Control: private, max-age=300'); echo $bytes; exit;
 }
 if($action==='clear_chat'){ $cust=trim($_POST['customer']??''); $stmt=$conn->prepare("UPDATE messages SET hidden_at=NOW() WHERE phone_number_id=? AND (sender_phone=? OR recipient_phone=?)"); $stmt->bind_param('iss',$localPhoneId,$cust,$cust); $stmt->execute(); $stmt->close(); out_json(['ok'=>true]); }
 if($action==='delete_chat'){ $cust=trim($_POST['customer']??''); $stmt=$conn->prepare("DELETE FROM messages WHERE phone_number_id=? AND (sender_phone=? OR recipient_phone=?)"); $stmt->bind_param('iss',$localPhoneId,$cust,$cust); $stmt->execute(); $stmt->close(); out_json(['ok'=>true]); }
 if($action==='block_user'){ $cust=trim($_POST['customer']??''); $esc=$conn->real_escape_string($cust); $check=$conn->query("SELECT id FROM blocked_users WHERE phone_number_id=$localPhoneId AND customer_phone='$esc' LIMIT 1"); if($check&&$check->num_rows>0){ $conn->query("DELETE FROM blocked_users WHERE phone_number_id=$localPhoneId AND customer_phone='$esc'"); out_json(['ok'=>true,'blocked'=>false]); } else { $conn->query("INSERT INTO blocked_users (phone_number_id,customer_phone) VALUES ($localPhoneId,'$esc')"); out_json(['ok'=>true,'blocked'=>true]); } }
 if($action==='delete_message_me'){ $id=(int)($_POST['message_id']??0); $stmt=$conn->prepare("UPDATE messages SET hidden_at=NOW() WHERE id=? AND phone_number_id=? LIMIT 1"); $stmt->bind_param('ii',$id,$localPhoneId); $stmt->execute(); $stmt->close(); out_json(['ok'=>true]); }
 if($action==='delete_message_everyone'){ $id=(int)($_POST['message_id']??0); $conn->query("UPDATE messages SET hidden_at=NOW(), message_text='🚫 You deleted this message', message_body='🚫 You deleted this message', status='deleted' WHERE id=$id AND phone_number_id=$localPhoneId"); out_json(['ok'=>true]); }
 if($action==='send'){
  $customer=trim($_POST['customer']??''); $text=trim($_POST['message']??''); $hasFile=isset($_FILES['attachment'])&&($_FILES['attachment']['error']??4)!==4; $voiceDoc=(($_POST['voice_document']??'')==='1');
  if($customer==='') out_json(['ok'=>false,'error'=>'Chat select karo'],400); if($text===''&&!$hasFile) out_json(['ok'=>false,'error'=>'Message likho'],400);
  $type='text'; $mediaId=null; $filename=null; $messageBody=$text; $mediaUrlLocal='';
  if($hasFile){
   $file=$_FILES['attachment']; $filename=preg_replace('/[^A-Za-z0-9._-]/','_',basename((string)$file['name'])); if(!$filename) $filename='file_'.time().'.bin';
   $mime=mime_content_type($file['tmp_name'])?:'application/octet-stream';
   if($voiceDoc){ $type='document'; $filename='voice_'.time().'.ogg'; $mime='audio/ogg'; }
   elseif(strpos($mime,'image/')===0) $type='image'; elseif(strpos($mime,'video/')===0) $type='video'; elseif(strpos($mime,'audio/')===0) $type='audio'; else $type='document';
   $curlFile=new CURLFile($file['tmp_name'],$mime,$filename);
   $up=graph_call('https://graph.facebook.com/'.$GRAPH_VERSION.'/'.rawurlencode((string)$userPhone['meta_phone_id']).'/media',$ACCESS_TOKEN,'POST',['messaging_product'=>'whatsapp','file'=>$curlFile,'type'=>$mime],true);
   if(!$up['ok']||empty($up['data']['id'])) out_json(['ok'=>false,'error'=>'Media upload fail: '.($up['data']['error']['message']??'')],502);
   $mediaId=(string)$up['data']['id']; $mObj=['id'=>$mediaId]; if($type==='document') $mObj['filename']=$filename; if($text!=='' && in_array($type,['image','video','document'],true)) $mObj['caption']=$text;
   $payload=['messaging_product'=>'whatsapp','to'=>$customer,'type'=>$type,$type=>$mObj]; if($text==='') $messageBody = $voiceDoc ? '' : '';
  } else { $payload=['messaging_product'=>'whatsapp','to'=>$customer,'type'=>'text','text'=>['preview_url'=>true,'body'=>$text]]; }
  $sent=graph_call('https://graph.facebook.com/'.$GRAPH_VERSION.'/'.rawurlencode((string)$userPhone['meta_phone_id']).'/messages',$ACCESS_TOKEN,'POST',json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  if(!$sent['ok']) out_json(['ok'=>false,'error'=>'Send fail: '.($sent['data']['error']['message']??'')],502);
  $wamid=$sent['data']['messages'][0]['id']??null; $sender=(string)$userPhone['phone_number'];
  $stmt=$conn->prepare('INSERT INTO messages (phone_number_id,sender_phone,recipient_phone,direction,message_text,message_body,message_type,msg_type,media_id,media_url,media_filename,wamid,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $dir='out'; $st='sent'; $stmt->bind_param('issssssssssss',$localPhoneId,$sender,$customer,$dir,$messageBody,$messageBody,$type,$type,$mediaId,$mediaUrlLocal,$filename,$wamid,$st); $stmt->execute(); $nid=$conn->insert_id; $stmt->close();
  out_json(['ok'=>true,'message'=>['id'=>$nid,'direction'=>'out','message_text'=>$messageBody,'message_type'=>$type,'media_id'=>$mediaId,'media_url'=>$mediaUrlLocal,'media_filename'=>$filename,'status'=>$st,'time_label'=>date('H:i')]]);
 }
 out_json(['ok'=>false,'error'=>'Unknown'],400);
}
$initialChats=[]; $selected='';
$sql="SELECT CASE WHEN ".incoming_sql()." THEN sender_phone ELSE recipient_phone END AS customer_phone, MAX(created_at) AS last_at, SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(NULLIF(message_text,''),NULLIF(message_body,''),CONCAT('[',COALESCE(NULLIF(message_type,''),NULLIF(msg_type,''),'media'),']')) ORDER BY created_at DESC SEPARATOR '\n'),'\n',1) AS last_message FROM messages WHERE phone_number_id=? AND hidden_at IS NULL GROUP BY customer_phone ORDER BY last_at DESC LIMIT 300";
$stmt=$conn->prepare($sql); $stmt->bind_param('i',$localPhoneId); $stmt->execute(); $r=$stmt->get_result(); while($r&&($row=$r->fetch_assoc())) $initialChats[]=$row; $stmt->close();
if(isset($_GET['chat'])){ $req=trim($_GET['chat']); foreach($initialChats as $c) if((string)$c['customer_phone']===$req){$selected=$req;break;} } elseif($initialChats) $selected=(string)($initialChats[0]['customer_phone']??'');
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"><title>WhatsApp Business</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}html,body{width:100%;height:100%;overflow:hidden;position:fixed;inset:0;background:#111b21;font-family:'Segoe UI',Helvetica,Arial,sans-serif;overscroll-behavior:none}
.app{display:flex;width:100vw;height:100dvh;overflow:hidden;background:#fff;position:fixed;inset:0}
.sidebar{width:32%;min-width:380px;max-width:480px;height:100%;display:flex;flex-direction:column;background:#fff;border-right:1px solid #e9edef;overflow:hidden}
.side-head{height:59px;min-height:59px;background:#f0f2f5;display:flex;align-items:center;justify-content:space-between;padding:0 16px;flex-shrink:0}
.iconbtn{width:40px;height:40px;min-width:40px;border:0;background:transparent;color:#54656f;font-size:20px;display:grid;place-items:center;cursor:pointer;border-radius:50%;flex-shrink:0}
.iconbtn svg{width:22px;height:22px;fill:#54656f}
.iconbtn:active{background:#e9edef}
.search{padding:7px 12px;background:#f0f2f5;flex-shrink:0}.search-box{background:#fff;border-radius:8px;height:35px;display:flex;align-items:center;gap:12px;padding:0 12px}.search-box input{border:0;outline:0;width:100%;font-size:14.5px;background:transparent}
.chat-list{flex:1;overflow-y:auto;background:#fff}.chat-row{width:100%;display:flex;gap:12px;padding:12px 14px;border:0;background:#fff;text-align:left;cursor:pointer;border-bottom:1px solid #f0f2f5}.chat-row.active{background:#ebebeb}
.avatar{width:49px;height:49px;min-width:49px;border-radius:50%;background:#00a884;color:#fff;display:grid;place-items:center;font-weight:600;flex-shrink:0}
.c-meta{flex:1;min-width:0}.c-top{display:flex;justify-content:space-between}.c-name{font-size:17px;color:#111b21;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.c-time{font-size:12px;color:#667781}.c-prev{font-size:13.5px;color:#667781;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bottom-nav{height:53px;min-height:53px;background:#f0f2f5;display:flex;justify-content:space-around;align-items:center;border-top:1px solid #e9edef;flex-shrink:0}
.bottom-nav svg{width:24px;height:24px;fill:#54656f}
.bottom-nav .active svg{fill:#00a884}
.main{flex:1;height:100%;display:flex;flex-direction:column;background:#efeae2;min-width:0;overflow:hidden}
.chat-head{height:59px;min-height:59px;background:#f0f2f5;display:flex;align-items:center;gap:4px;padding:0 6px 0 10px;flex-shrink:0;position:relative}
.chat-menu{display:none;position:absolute;top:59px;right:8px;width:260px;background:#fff;border-radius:8px;box-shadow:0 2px 12px rgba(0,0,0,.25);z-index:30;padding:8px 0}.chat-menu.open{display:block}.chat-menu button{width:100%;padding:14px 20px;border:0;background:#fff;text-align:left;font-size:15px;display:flex;align-items:center;gap:14px;cursor:pointer}.chat-menu button.danger{color:#ea0038}
.messages{flex:1;overflow-y:auto;padding:12px 6%;display:flex;flex-direction:column;gap:2px;background:#efeae2;background-image:url("https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png")}
.bubble{max-width:65%;padding:6px 7px 8px 9px;border-radius:7.5px;box-shadow:0 1px .5px rgba(0,0,0,.13);font-size:14.2px;line-height:19px;position:relative;word-break:break-word}
.bubble.in{background:#fff;align-self:flex-start;border-top-left-radius:0}.bubble.out{background:#d9fdd3;align-self:flex-end;border-top-right-radius:0}
.bubble-text{white-space:pre-wrap; line-height:20px}
.bubble-text a{color:#008069; text-decoration:none; word-break:break-all}
.bubble-text a:hover{text-decoration:underline}
.bubble.has-img{padding:3px !important; max-width: 200px !important}
.bubble.has-img .bubble-text{padding:3px 4px 2px}
.bubble.has-img img{max-width:180px !important; max-height:220px !important; width:100%; height:auto; border-radius:6px; display:block; cursor:pointer; object-fit:cover}
.bubble video{max-width:180px !important; max-height:220px; border-radius:6px; display:block}
.bubble audio{width:230px; display:block}
.link-card{background:#f0f2f5; border-radius:7px; padding:0; margin-bottom:6px; overflow:hidden; border:1px solid #e9edef; cursor:pointer}
.link-card-inner{padding:8px 10px; border-left:4px solid #00a884; background:#fff}
.link-card-title{font-weight:600; font-size:14.5px; color:#111b21; line-height:19px}
.link-card-domain{font-size:12.5px; color:#667781; display:flex; align-items:center; gap:4px; margin:3px 0}
.link-card-url{font-size:13.5px; color:#008069; word-break:break-all; text-decoration:underline; line-height:18px}
.bubble-meta{font-size:11px; color:#667781; float:right; margin-left:10px; margin-top:6px; display:flex; align-items:center; gap:3px}
.bubble.has-img .bubble-meta{position:absolute; bottom:4px; right:6px; background:rgba(0,0,0,0.35); color:#fff; padding:1px 6px; border-radius:10px; font-size:10px}
.bubble.has-img .bubble-meta .tick{color:#fff !important}
.tick{font-size:13px; line-height:1}
.tick.read{color:#53bdeb !important}
.tick.delivered{color:#667781}
.tick.sent{color:#667781}
.empty{margin:auto;background:#fff;padding:10px 14px;border-radius:8px;font-size:12.5px;color:#667781}
.composer{height:62px;min-height:62px;background:#f0f2f5;display:flex;align-items:center;gap:2px;padding:5px 6px;flex-shrink:0;overflow:hidden;position:relative;z-index:3}
.input-wrap{flex:1;min-width:0;background:#fff;border-radius:21px;height:42px;display:flex;align-items:center;padding:0 12px;overflow:hidden}.input-wrap textarea{flex:1;min-width:0;border:0;outline:0;resize:none;background:transparent;font-size:15px;line-height:20px;padding:9px 0;max-height:42px;overflow-y:auto}
.mic-btn,.send-btn{width:45px;height:45px;min-width:45px;border-radius:50%;background:#00a884;color:#fff;border:0;display:grid;place-items:center;cursor:pointer;flex-shrink:0;margin-left:4px}
.mic-btn svg,.send-btn svg{width:22px;height:22px;fill:#fff}
.toast{position:absolute;bottom:70px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:8px 16px;border-radius:20px;font-size:13px;display:none;z-index:999;max-width:85%;text-align:center}.toast.show{display:block}
.voice-ui{display:none;position:absolute;inset:0;background:#f0f2f5;z-index:10;align-items:center;gap:10px;padding:0 10px}.voice-ui.active{display:flex}.v-time{font-weight:600;min-width:35px}
.mobile-back{display:none}
.msg-menu{position:fixed;background:#fff;border-radius:8px;box-shadow:0 4px 16px rgba(0,0,0,.3);z-index:100;padding:6px 0;width:200px;display:none}.msg-menu.open{display:block}.msg-menu button{width:100%;padding:12px 16px;border:0;background:#fff;text-align:left;font-size:14px;cursor:pointer}
@media(max-width:900px){.sidebar{width:100%;min-width:100%;position:absolute;inset:0;z-index:5}.main{position:absolute;inset:0;z-index:6;display:none}.app.chat-open .main{display:flex}.app.chat-open .sidebar{display:none}.mobile-back{display:grid}.bubble{max-width:80%} .bubble.has-img{max-width:65% !important}}
</style></head><body>
<div class="app" id="app">
<aside class="sidebar"><div class="side-head"><b>WhatsApp</b><a href="logout.php" style="color:#54656f;text-decoration:none;font-size:13px;padding:6px">Logout</a></div>
<div class="search"><div class="search-box"><span>⌕</span><input id="searchChats" placeholder="Search"></div></div>
<div class="chat-list" id="chatList"><?php foreach($initialChats as $c){ $n=(string)$c['customer_phone']; $last=(string)($c['last_message']??''); $low=strtolower($last); if(strpos($low,'audio')!==false||strpos($low,'voice')!==false) $last='🎤 Voice'; elseif(strpos($low,'image')!==false) $last='📷 Photo'; $time=date('H:i',strtotime($c['last_at']??'now')); echo '<button class="chat-row '.($n===$selected?'active':'').'" data-customer="'.h($n).'"><div class="avatar">'.h(strtoupper(substr($n,-2))).'</div><div class="c-meta"><div class="c-top"><div class="c-name">'.h($n).'</div><div class="c-time">'.$time.'</div></div><div class="c-prev">'.h($last).'</div></div></button>'; } ?></div>
<div class="bottom-nav"><button style="flex:1;border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:2px" class="active"><svg viewBox="0 0 24 24"><path d="M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM6 14a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm4 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm4 0a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/></svg><span style="font-size:11px;color:#00a884">Chats</span></button><button style="flex:1;border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:2px" onclick="toast('یہ فیچر API کے لیے دستیاب نہیں')"><svg viewBox="0 0 24 24"><path d="M12 2A10 10 0 1 0 22 12 10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8zm-2-8.5A1.5 1.5 0 1 1 11.5 13 1.5 1.5 0 0 1 10 11.5zm5 0A1.5 1.5 0 1 1 16.5 13 1.5 1.5 0 0 1 15 11.5z"/></svg><span style="font-size:11px;color:#54656f">Updates</span></button><button style="flex:1;border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:2px" onclick="toast('یہ فیچر API کے لیے دستیاب نہیں')"><svg viewBox="0 0 24 24"><path d="M12 2a5 5 0 0 0-5 5v2a5 5 0 0 0 10 0V7a5 5 0 0 0-5-5zm-7 10c-1.1 0-2 .9-2 2v2a2 2 0 0 0 2 2h1v-6H5zm14 0v6h1a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-1zm-7 8a7 7 0 0 1-7-7H3a9 9 0 0 0 18 0h-2a7 7 0 0 1-7 7z"/></svg><span style="font-size:11px;color:#54656f">Communities</span></button><button style="flex:1;border:0;background:transparent;display:flex;flex-direction:column;align-items:center;gap:2px" onclick="toast('یہ فیچر API کے لیے دستیاب نہیں')"><svg viewBox="0 0 24 24"><path d="M20 10.5V6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 3z"/></svg><span style="font-size:11px;color:#54656f">Calls</span></button></div>
</aside>
<main class="main"><header class="chat-head">
<button class="iconbtn mobile-back" id="backBtn"><svg viewBox="0 0 24 24"><path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"/></svg></button>
<div class="avatar">W</div><div style="flex:1;min-width:0"><strong id="activeName"><?= h($selected?:'Select') ?></strong><div style="font-size:13px;color:#667781">tap for info</div></div>
<button class="iconbtn" id="callBtn"><svg viewBox="0 0 24 24"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.98.98 0 0 0-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02A11.36 11.36 0 0 1 8.65 4c0-.55-.45-1-1-1H4.08c-.55 0-1 .45-1 1 0 9.39 7.61 17 17 17 .55 0 1-.45 1-1v-3.49c0-.55-.45-1-1-1z"/></svg></button>
<button class="iconbtn" id="videoBtn"><svg viewBox="0 0 24 24"><path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"/></svg></button>
<button class="iconbtn" id="menuBtn"><svg viewBox="0 0 24 24"><path d="M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg></button>
<div class="chat-menu" id="chatMenu"><button data-act="clear_chat">🧹 Clear Chat</button><button data-act="delete_chat" class="danger">🗑️ Delete Chat</button><button data-act="block_user" class="danger">🚫 Block User</button></div></header>
<div class="messages" id="messages"><div class="empty">🔒 End-to-end encrypted</div></div>
<form class="composer" id="composer" enctype="multipart/form-data">
<button type="button" class="iconbtn" id="emojiBtn"><svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8zM8 14a4 4 0 0 0 8 0H8zm1.5-4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z"/></svg></button>
<div class="input-wrap"><textarea id="messageInput" rows="1" placeholder="Message"></textarea></div>
<button type="button" class="iconbtn" id="attachBtn"><svg viewBox="0 0 24 24"><path d="M16.5 6v11.5a4 4 0 0 1-4 4 4 4 0 0 1-4-4V5a2.5 2.5 0 0 1 5 0v10.5a1 1 0 0 1-2 0V6H10v9.5a2.5 2.5 0 0 0 5 0V6h-2.5z"/></svg></button>
<input type="file" id="attachment" style="display:none" accept="image/*,video/*,audio/*,.pdf,.ogg,.webm,.m4a">
<button type="button" class="iconbtn" id="camBtn"><svg viewBox="0 0 24 24"><path d="M12 8a4 4 0 1 0 4 4 4 4 0 0 0-4-4zm0 6a2 2 0 1 1 0-4 2 2 0 0 1 0 4zM20 4h-2.6l-1.2-1.2A1 1 0 0 0 15.5 2h-7a1 1 0 0 0-.7.3L6.6 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 14H4V6h3a1 1 0 0 0 .7-.3L8.9 4h6.2l1.2 1.2A1 1 0 0 0 17 6h3z"/></svg></button>
<button type="button" class="mic-btn" id="micBtn"><svg viewBox="0 0 24 24"><path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2z"/></svg></button>
<button type="submit" class="send-btn" id="sendBtn" style="display:none"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button>
<div class="voice-ui" id="voiceUI"><span class="v-time" id="recTime">0:00</span><div style="flex:1"></div><button type="button" class="iconbtn" id="delBtn"><svg viewBox="0 0 24 24" style="fill:#f15c6d"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg></button><button type="button" class="send-btn" id="voiceSendBtn"><svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg></button></div></form><div class="toast" id="toast"></div></main>
</div>
<div class="msg-menu" id="msgMenu"><button data-del="me">🗑️ Delete for me</button><button data-del="everyone">🚫 Delete for everyone</button></div>
<script>
const CSRF=<?= json_encode($csrf) ?>; let activeCustomer=<?= json_encode($selected) ?>; let lastMessageId=0,mediaRecorder=null,recordedChunks=[],recordedBlob=null,recording=false,recTimer=null,recSeconds=0,pendingSend=false,selectedMsgId=0;
const app=document.getElementById('app'),chatList=document.getElementById('chatList'),messagesEl=document.getElementById('messages'),input=document.getElementById('messageInput'),fileInput=document.getElementById('attachment'),toastEl=document.getElementById('toast'),micBtn=document.getElementById('micBtn'),sendBtn=document.getElementById('sendBtn'),voiceUI=document.getElementById('voiceUI'),recTimeEl=document.getElementById('recTime'),msgMenu=document.getElementById('msgMenu');
function toast(m){toastEl.textContent=m;toastEl.classList.add('show');setTimeout(()=>toastEl.classList.remove('show'),2800);}
function apiUrl(a,p={}){const u=new URL(location.href);u.search='';u.searchParams.set('ajax','1');u.searchParams.set('action',a);Object.entries(p).forEach(([k,v])=>u.searchParams.set(k,String(v)));return u.toString();}
async function request(url,opt={}){const r=await fetch(url,{credentials:'same-origin',...opt});let d;try{d=await r.json()}catch(e){throw new Error('Invalid')} if(!r.ok||!d.ok) throw new Error(d.error||'Fail');return d;}
async function postAction(a,f={}){const fd=new FormData();fd.append('csrf_token',CSRF);fd.append('action',a);Object.entries(f).forEach(([k,v])=>fd.append(k,String(v)));return request(apiUrl(a),{method:'POST',body:fd});}
function safeText(v){return String(v==null?'':v)}
function escapeHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function getMediaSrc(m){ if(m.media_url && m.media_url.includes('uploads/')){ if(m.media_url.startsWith('http')) return m.media_url; return '/' + m.media_url.replace(/^\/+/,''); } if(m.media_id) return apiUrl('media',{id:m.media_id}); return ''; }
function tickHtml(status, direction){ if(direction !== 'out') return ''; status = String(status||'sent').toLowerCase(); if(status === 'read' || status === 'seen') return '<span class="tick read">✓✓</span>'; if(status === 'delivered') return '<span class="tick delivered">✓✓</span>'; if(status === 'sent') return '<span class="tick sent">✓✓</span>'; if(status === 'failed') return '<span class="tick" style="color:#f15c6d">✕</span>'; return '<span class="tick sent">✓</span>'; }
function linkify(text){ let escaped = escapeHtml(text); const urlRegex = /(https?:\/\/[^\s]+)/g; escaped = escaped.replace(urlRegex, function(url){ return '<a href="'+url+'" target="_blank" rel="noopener">'+url+'</a>'; }); escaped = escaped.replace(/\n/g,'<br>'); return escaped; }
function getLinkPreview(text){ const m = text.match(/https?:\/\/[^\s]+/); if(!m) return null; try{ const u = new URL(m[0]); const domain = u.hostname.replace(/^www\./,''); let title = domain; if(domain.includes('munafaportal')) title = 'Signup | MunafaPortal'; else if(domain.includes('fastsky')) title = 'FastSkyz Online'; else title = domain; return {url: m[0], domain: domain, title: title}; }catch(e){ return null; } }
function addBubble(m){
 if(!m||!m.id) return; if(messagesEl.querySelector('[data-id="'+m.id+'"]')) return;
 const first=messagesEl.querySelector('.empty'); if(first&&messagesEl.children.length===1) first.remove();
 const b=document.createElement('div'); b.className='bubble '+(m.direction==='out'?'out':'in'); b.dataset.id=m.id;
 const typeRaw=String(m.message_type||'').toLowerCase();
 let txt=safeText(m.message_text);
 const lowTxt=txt.toLowerCase().trim();
 const fileName=safeText(m.media_filename).toLowerCase();
 const isPlaceholder = lowTxt.includes('[image message]')||lowTxt.includes('[audio message]')||lowTxt.includes('[voice message]')||lowTxt==='[image]'||lowTxt==='..'||lowTxt==='';
 const isVoice = fileName.includes('voice')||fileName.endsWith('.ogg')||typeRaw.includes('audio')||typeRaw==='voice'||typeRaw==='ptt';
 const isImage = typeRaw.includes('image')||fileName.match(/\.(jpg|jpeg|png|gif|webp)$/);
 const isVideo = typeRaw.includes('video');
 const src=getMediaSrc(m);
 if(src && isImage){
   b.classList.add('has-img');
   const img=document.createElement('img'); img.src=src; img.loading='lazy'; img.onclick=()=>window.open(src,'_blank'); b.appendChild(img);
   if(!isPlaceholder && txt.trim()!=='' && !txt.toLowerCase().includes('screenshot_')) { const d=document.createElement('div'); d.className='bubble-text'; const prev = getLinkPreview(txt); if(prev){ const card=document.createElement('div'); card.className='link-card'; card.innerHTML='<div class="link-card-inner"><div class="link-card-title">'+escapeHtml(prev.title)+'</div><div class="link-card-domain">🔗 '+escapeHtml(prev.domain)+'</div><div class="link-card-url">'+escapeHtml(prev.url)+'</div></div>'; card.onclick=()=>window.open(prev.url,'_blank'); b.appendChild(card); } d.innerHTML=linkify(txt); b.appendChild(d); }
 } else if(src && isVoice){ const audio=document.createElement('audio'); audio.src=src; audio.controls=true; audio.preload='metadata'; b.appendChild(audio);
 } else if(src && isVideo){ b.classList.add('has-img'); const v=document.createElement('video'); v.src=src; v.controls=true; b.appendChild(v); if(!isPlaceholder && txt.trim()!=='') { const d=document.createElement('div'); d.className='bubble-text'; d.innerHTML=linkify(txt); b.appendChild(d); }
 } else if(src){ if(fileName.match(/\.(jpg|jpeg|png|webp)$/)){ b.classList.add('has-img'); const img=document.createElement('img'); img.src=src; b.appendChild(img); } else if(fileName.match(/\.(ogg|webm|mp3|m4a|wav)$/)||typeRaw.includes('audio')||typeRaw.includes('document')){ const audio=document.createElement('audio'); audio.src=src; audio.controls=true; b.appendChild(audio); } else { const a=document.createElement('a'); a.href=src; a.target='_blank'; a.style.cssText='display:block;padding:8px;background:rgba(0,0,0,.05);border-radius:6px;text-decoration:none;color:#111'; a.textContent='📄 '+(m.media_filename||'Document'); b.appendChild(a); } } else {
   if(txt && txt.trim()!=='' && !txt.toLowerCase().includes('[image message]') && !txt.toLowerCase().includes('[audio message]') && !txt.toLowerCase().includes('[voice message]') && txt.trim()!=='..'){
     const prev = getLinkPreview(txt); if(prev){ const card=document.createElement('div'); card.className='link-card'; card.innerHTML='<div class="link-card-inner"><div class="link-card-title">'+escapeHtml(prev.title)+'</div><div class="link-card-domain">🔗 '+escapeHtml(prev.domain)+'</div><div class="link-card-url">'+escapeHtml(prev.url)+'</div></div>'; card.onclick=()=>window.open(prev.url,'_blank'); b.appendChild(card); }
     const d=document.createElement('div'); d.className='bubble-text'; d.innerHTML=linkify(txt); b.appendChild(d);
   }
 }
 const meta=document.createElement('div'); meta.className='bubble-meta'; meta.innerHTML = '<span>'+(m.time_label||'')+'</span><span class="ticks-wrap">'+tickHtml(m.status, m.direction)+'</span>'; b.appendChild(meta);
 b.dataset.status = m.status||'sent';
 b.addEventListener('contextmenu',e=>{e.preventDefault(); selectedMsgId=m.id; msgMenu.style.left=e.pageX+'px'; msgMenu.style.top=e.pageY+'px'; msgMenu.classList.add('open');});
 let pressTimer; b.addEventListener('touchstart',e=>{pressTimer=setTimeout(()=>{selectedMsgId=m.id; const touch=e.touches[0]; msgMenu.style.left=touch.pageX+'px'; msgMenu.style.top=touch.pageY+'px'; msgMenu.classList.add('open');},600);}); b.addEventListener('touchend',()=>clearTimeout(pressTimer));
 messagesEl.appendChild(b); lastMessageId=Math.max(lastMessageId,Number(m.id));
}
function updateTicks(statuses){ if(!statuses) return; statuses.forEach(s=>{ const el = messagesEl.querySelector('[data-id="'+s.id+'"]'); if(el){ const wrap = el.querySelector('.ticks-wrap'); if(wrap) wrap.innerHTML = tickHtml(s.status, 'out'); el.dataset.status = s.status; } }); }
async function loadMessages(init=false){ if(!activeCustomer) return; const near=messagesEl.scrollHeight-messagesEl.scrollTop-messagesEl.clientHeight<120; try{ const data=await request(apiUrl('messages',{customer:activeCustomer,after:init?0:lastMessageId})); if(init){messagesEl.innerHTML=''; lastMessageId=0;} if(!data.messages.length&&init){messagesEl.innerHTML='<div class="empty">No messages yet</div>'; return;} data.messages.forEach(addBubble); if(init||near) messagesEl.scrollTop=messagesEl.scrollHeight; }catch(e){} }
async function syncStatus(){ if(!activeCustomer) return; try{ const data = await request(apiUrl('status_sync',{customer:activeCustomer})); updateTicks(data.statuses||[]); }catch(e){} }
function openChat(c){ activeCustomer=c; lastMessageId=0; const u=new URL(location.href); u.searchParams.set('chat',c); history.replaceState({},'',u); document.getElementById('activeName').textContent=c; app.classList.add('chat-open'); document.querySelectorAll('.chat-row').forEach(r=>r.classList.toggle('active',r.dataset.customer===c)); loadMessages(true); }
chatList.addEventListener('click',e=>{const r=e.target.closest('.chat-row'); if(r) openChat(r.dataset.customer);});
document.getElementById('backBtn').onclick=()=>app.classList.remove('chat-open');
document.getElementById('attachBtn').onclick=()=>fileInput.click();
document.getElementById('camBtn').onclick=()=>fileInput.click();
fileInput.onchange=()=>{updateBtns();};
function updateBtns(){ const has=input.value.trim().length>0||fileInput.files.length>0||recordedBlob; if(has){ micBtn.style.display='none'; sendBtn.style.display='grid'; } else { micBtn.style.display='grid'; sendBtn.style.display='none'; } }
input.addEventListener('input',()=>{ input.style.height='auto'; input.style.height=Math.min(input.scrollHeight,42)+'px'; updateBtns(); });
input.addEventListener('keydown',e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); document.getElementById('composer').requestSubmit(); } });
function startTimer(){recSeconds=0;recTimeEl.textContent='0:00';clearInterval(recTimer);recTimer=setInterval(()=>{recSeconds++;const m=Math.floor(recSeconds/60),s=recSeconds%60;recTimeEl.textContent=m+':'+(s<10?'0':'')+s;},1000);}
function stopTimer(){clearInterval(recTimer);}
async function actuallySend(){ const text=input.value.trim(); if(!text&&!fileInput.files.length&&!recordedBlob) return; const fd=new FormData(); fd.append('csrf_token',CSRF); fd.append('action','send'); fd.append('customer',activeCustomer); fd.append('message',text); if(recordedBlob){ fd.append('attachment',recordedBlob,'voice_'+Date.now()+'.ogg'); fd.append('voice_document','1'); } else if(fileInput.files[0]) fd.append('attachment',fileInput.files[0]); sendBtn.disabled=true; try{ const data=await request(apiUrl('send'),{method:'POST',body:fd}); addBubble(data.message); messagesEl.scrollTop=messagesEl.scrollHeight; input.value=''; fileInput.value=''; recordedBlob=null; stopTimer(); voiceUI.classList.remove('active'); recording=false; updateBtns(); await loadChats(); }catch(err){ toast(err.message); } finally{ sendBtn.disabled=false; } }
document.getElementById('composer').onsubmit=async e=>{ e.preventDefault(); if(recording){ pendingSend=true; if(mediaRecorder&&mediaRecorder.state!=='inactive') mediaRecorder.stop(); return; } await actuallySend(); };
micBtn.onclick=async()=>{ try{ const stream=await navigator.mediaDevices.getUserMedia({audio:true}); let mime=''; if(MediaRecorder.isTypeSupported('audio/webm;codecs=opus')) mime='audio/webm;codecs=opus'; else if(MediaRecorder.isTypeSupported('audio/ogg;codecs=opus')) mime='audio/ogg;codecs=opus'; recordedChunks=[]; mediaRecorder=new MediaRecorder(stream,mime?{mimeType:mime}:{}); mediaRecorder.ondataavailable=e=>{if(e.data.size) recordedChunks.push(e.data);}; mediaRecorder.onstop=()=>{ recordedBlob=new Blob(recordedChunks,{type:'audio/ogg'}); stream.getTracks().forEach(t=>t.stop()); recording=false; stopTimer(); if(pendingSend){ pendingSend=false; actuallySend(); } else { voiceUI.classList.remove('active'); updateBtns(); } }; mediaRecorder.start(); recording=true; startTimer(); voiceUI.classList.add('active'); }catch(err){ toast('Mic ke liye HTTPS chahiye'); } };
document.getElementById('delBtn').onclick=()=>{ if(mediaRecorder&&mediaRecorder.state!=='inactive') mediaRecorder.stop(); recording=false; recordedBlob=null; pendingSend=false; stopTimer(); voiceUI.classList.remove('active'); updateBtns(); };
document.getElementById('voiceSendBtn').onclick=()=>{ if(recording){ pendingSend=true; mediaRecorder.stop(); } else if(recordedBlob){ actuallySend(); } };
function renderChats(chats){ chatList.innerHTML=''; chats.forEach(chat=>{ const number=String(chat.customer_phone||''); let last=String(chat.last_message||''); const low=last.toLowerCase(); if(low.includes('audio')||low.includes('voice')) last='🎤 Voice message'; else if(low.includes('image')) last='📷 Photo'; const time=chat.last_at? new Date(chat.last_at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : ''; const row=document.createElement('button'); row.className='chat-row'+(number===activeCustomer?' active':''); row.dataset.customer=number; row.innerHTML='<div class="avatar">'+number.slice(-2).toUpperCase()+'</div><div class="c-meta"><div class="c-top"><div class="c-name">'+number+'</div><div class="c-time">'+time+'</div></div><div class="c-prev">'+last+'</div></div>'; chatList.appendChild(row); });}
async function loadChats(){ try{ const data=await request(apiUrl('chats')); renderChats(data.chats); }catch(e){} }
document.getElementById('searchChats').oninput=e=>{const q=e.target.value.toLowerCase(); document.querySelectorAll('.chat-row').forEach(r=>{ r.style.display=r.textContent.toLowerCase().includes(q)?'flex':'none';});};
document.getElementById('menuBtn').onclick=()=>document.getElementById('chatMenu').classList.toggle('open');
document.getElementById('chatMenu').onclick=async e=>{
 const btn=e.target.closest('[data-act]'); if(!btn) return; const act=btn.dataset.act; document.getElementById('chatMenu').classList.remove('open');
 if(!activeCustomer){ toast('Pehle chat select karo'); return; }
 if(act==='clear_chat'){ if(!confirm('Clear Chat? Sirf messages delete honge, number rahega.')) return; await postAction('clear_chat',{customer:activeCustomer}); messagesEl.innerHTML='<div class="empty">Chat cleared</div>'; toast('Cleared'); }
 if(act==='delete_chat'){ if(!confirm('Delete Chat? Sara chat delete ho jayega.')) return; await postAction('delete_chat',{customer:activeCustomer}); activeCustomer=''; app.classList.remove('chat-open'); messagesEl.innerHTML='<div class="empty">Select chat</div>'; await loadChats(); toast('Deleted'); }
 if(act==='block_user'){ if(!confirm('Block this user?')) return; const res=await postAction('block_user',{customer:activeCustomer}); toast(res.blocked?'Blocked':'Unblocked'); }
};
msgMenu.onclick=async e=>{
 const btn=e.target.closest('[data-del]'); if(!btn) return; const type=btn.dataset.del; msgMenu.classList.remove('open');
 if(type==='me'){ await postAction('delete_message_me',{message_id:selectedMsgId}); document.querySelector('[data-id="'+selectedMsgId+'"]')?.remove(); toast('Deleted for me'); }
 if(type==='everyone'){ if(!confirm('Delete for everyone?')) return; await postAction('delete_message_everyone',{message_id:selectedMsgId}); const el=document.querySelector('[data-id="'+selectedMsgId+'"]'); if(el){ const t=el.querySelector('.bubble-text'); if(t) t.textContent='🚫 You deleted this message'; } toast('Deleted'); }
};
document.addEventListener('click',e=>{ if(!e.target.closest('#menuBtn')&&!e.target.closest('#chatMenu')) document.getElementById('chatMenu').classList.remove('open'); if(!e.target.closest('.bubble')&&!e.target.closest('#msgMenu')) msgMenu.classList.remove('open'); });
document.getElementById('callBtn').onclick=()=>toast('یہ فیچر API کے لیے دستیاب نہیں');
document.getElementById('videoBtn').onclick=()=>toast('یہ فیچر API کے لیے دستیاب نہیں');
document.getElementById('emojiBtn').onclick=()=>{ input.value+='😊'; updateBtns(); input.focus(); };
if(activeCustomer){app.classList.add('chat-open'); loadMessages(true);} updateBtns(); loadChats();
setInterval(()=>{ loadChats(); if(activeCustomer) loadMessages(false); },4000);
setInterval(()=>{ if(activeCustomer) syncStatus(); },3000);
</script></body></html>