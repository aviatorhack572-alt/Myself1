<?php
session_start();
require_once "../config.php";

if (!isset($_SESSION['user_id'])) {
    exit("Unauthorized");
}

$phone_number_id = $_SESSION['phone_number_id'] ?? 1;
$chat_id = isset($_GET['chat_id']) ? $_GET['chat_id'] : '';

if (!empty($chat_id)) {
    $msg_q = $conn->prepare("SELECT * FROM messages WHERE phone_number_id = ? AND sender_phone = ? ORDER BY id ASC");
    $msg_q->bind_param("is", $phone_number_id, $chat_id);
    $msg_q->execute();
    $msg_res = $msg_q->get_result();

    while ($m = $msg_res->fetch_assoc()) {
        $is_out = ($m['direction'] == 'outbound');
        $bubble_class = $is_out ? 'msg-out ml-auto' : 'msg-in mr-auto';
        $align_class = $is_out ? 'flex justify-end' : 'flex justify-start';
        
        echo '<div class="' . $align_class . ' mb-2"><div class="' . $bubble_class . ' max-w-[85%] lg:max-w-md px-4 py-2 rounded-lg shadow-sm text-sm relative"><p class="text-gray-800 break-words">' . nl2br(htmlspecialchars($m['message_body'])) . '</p>';
        
        if (!empty($m['media_url'])) {
            $file_path = "../" . $m['media_url'];
            if ($m['msg_type'] == 'image') {
                echo '<img src="' . htmlspecialchars($file_path) . '" class="mt-2 rounded max-w-full h-auto max-h-60 object-cover">';
            } elseif ($m['msg_type'] == 'audio') {
                echo '<audio controls class="mt-2 w-full max-w-xs"><source src="' . htmlspecialchars($file_path) . '"></audio>';
            } else {
                echo '<br><a href="' . htmlspecialchars($file_path) . '" target="_blank" class="text-blue-600 text-xs underline mt-1 block"><i class="fa-solid fa-download"></i> فائل ڈاؤن لوڈ کریں</a>';
            }
        }
        echo '<span class="text-[10px] text-gray-400 block text-right mt-1">' . $m['created_at'] . '</span></div></div>';
    }
}
?>
