<?php
// ڈیٹا بیس کنکشن
$db_host = "localhost";
$db_name = "u673702293_api";
$db_user = "u673702293_api";
$db_pass = "hAMRAZ12@"; // <-- یہاں Hostinger والا پاسورڈ لکھو

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Database Connection Failed: ". $conn->connect_error);
}

// آپ کے ٹوکنز - ایک ہی جگہ
$ACCESS_TOKEN = "EAAfaUxorx2UBSr7Wh0Uysjk1RSKIR5a2ZC4rPUq2vKTYHMZC7fhAUds4CAvmG9HTZC6ZC47ZC4ugPNE0zYTLZBtbxDZBdGPAkl1VZCGvrfHeLJYXLVwF3s4IFvCdoBMXF1L40GJZBSEAXeTHDWZAFB9ptrzBO9EihDDq4GIqt1HZBFoIZCFMLCUGvr9oVmgUS44HEfdErAZDZD";
$VERIFY_TOKEN = "my_secure_token_123";
?>