<?php
require_once "config.php";

if (isset($_GET['hub_mode']) && $_GET['hub_mode'] == 'subscribe') {
    if (isset($_GET['hub_challenge'])) { echo $_GET['hub_challenge']; exit; }
}

$input = file_get_contents('php://input');
$data = json_decode($input, true);
file_put_contents("log.txt", date('Y-m-d H:i:s')." ".$input."\n\n", FILE_APPEND);

if (!$data || !isset($data['entry'][0]['changes'][0]['value'])) { http_response_code(200); exit; }
$value = $data['entry'][0]['changes'][0]['value'];

// Status - blue tick ke liye
if (isset($value['statuses'][0])) {
    $wamid = $value['statuses'][0]['id'] ?? '';
    $status = $value['statuses'][0]['status'] ?? '';
    if ($wamid && $status) {
        $conn->query("UPDATE messages SET status='".$conn->real_escape_string($status)."' WHERE wamid='".$conn->real_escape_string($wamid)."' LIMIT 1");
    }
    http_response_code(200); exit;
}

if (!isset($value['messages'][0])) { http_response_code(200); exit; }

$phone_id_meta = $value['metadata']['phone_number_id'] ?? '';
$msg = $value['messages'][0];
$wa_id = $msg['from'] ?? '';
$type = $msg['type'] ?? 'text';
$wamid = $msg['id'] ?? '';

$q = $conn->query("SELECT id, phone_number FROM phone_numbers WHERE phone_id = '".$conn->real_escape_string($phone_id_meta)."' LIMIT 1");
$phone_row_id = 1; $own_number = '';
if ($q && $q->num_rows > 0) { $r = $q->fetch_assoc(); $phone_row_id = $r['id']; $own_number = $r['phone_number']; }

$message_body = ''; $media_id_db = ''; $media_url_db = ''; $media_filename_db = '';

if ($type == 'text') {
    $message_body = $msg['text']['body'] ?? '';
} else {
    $media_id = ''; $mime_type = '';
    if ($type == 'image' && isset($msg['image']['id'])) {
        $media_id = $msg['image']['id']; $mime_type = $msg['image']['mime_type'] ?? 'image/jpeg';
        $message_body = $msg['image']['caption'] ?? ''; $media_filename_db = 'image.jpg';
    } elseif ($type == 'audio' && isset($msg['audio']['id'])) {
        $media_id = $msg['audio']['id']; $mime_type = $msg['audio']['mime_type'] ?? 'audio/ogg';
        $message_body = ''; $media_filename_db = 'voice_'.time().'.ogg'; $type = 'audio';
    } elseif ($type == 'voice' && isset($msg['voice']['id'])) {
        $media_id = $msg['voice']['id']; $mime_type = $msg['voice']['mime_type'] ?? 'audio/ogg';
        $message_body = ''; $media_filename_db = 'voice_'.time().'.ogg'; $type = 'audio';
    } elseif ($type == 'video' && isset($msg['video']['id'])) {
        $media_id = $msg['video']['id']; $mime_type = $msg['video']['mime_type'] ?? 'video/mp4';
        $message_body = $msg['video']['caption'] ?? ''; $media_filename_db = 'video.mp4';
    } elseif ($type == 'document' && isset($msg['document']['id'])) {
        $media_id = $msg['document']['id']; $mime_type = $msg['document']['mime_type'] ?? '';
        $media_filename_db = $msg['document']['filename'] ?? 'document.pdf'; $message_body = $media_filename_db;
    }

    if (!empty($media_id)) {
        $media_id_db = $media_id;
        if (!empty($ACCESS_TOKEN)) {
            $ver = isset($GRAPH_API_VERSION) ? $GRAPH_API_VERSION : 'v23.0';
            $ch = curl_init("https://graph.facebook.com/$ver/{$media_id}");
            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".$ACCESS_TOKEN]);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $res = curl_exec($ch); curl_close($ch);
            $j = json_decode($res, true);
            if (isset($j['url'])) {
                $ch2 = curl_init($j['url']);
                curl_setopt($ch2, CURLOPT_HTTPHEADER, ["Authorization: Bearer ".$ACCESS_TOKEN]);
                curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
                $bin = curl_exec($ch2); curl_close($ch2);
                if ($bin) {
                    $ext = 'bin';
                    if (strpos($mime_type,'jpeg')!==false||strpos($mime_type,'jpg')!==false) $ext='jpg';
                    elseif (strpos($mime_type,'png')!==false) $ext='png';
                    elseif (strpos($mime_type,'ogg')!==false) $ext='ogg';
                    elseif (strpos($mime_type,'mp4')!==false) $ext='mp4';
                    elseif (strpos($mime_type,'mp3')!==false) $ext='mp3';
                    $dir = "uploads/media/"; if(!is_dir($dir)) mkdir($dir,0777,true);
                    $fname = time()."_".rand(1000,9999).".".$ext;
                    if(file_put_contents($dir.$fname,$bin)){ $media_url_db = $dir.$fname; }
                }
            }
        }
    }
}

$sql = "INSERT INTO messages (phone_number_id,sender_phone,recipient_phone,direction,message_text,message_body,message_type,msg_type,media_id,media_url,media_filename,wamid,status,created_at) VALUES ('$phone_row_id','".$conn->real_escape_string($wa_id)."','".$conn->real_escape_string($own_number)."','in','".$conn->real_escape_string($message_body)."','".$conn->real_escape_string($message_body)."','".$conn->real_escape_string($type)."','".$conn->real_escape_string($type)."','".$conn->real_escape_string($media_id_db)."','".$conn->real_escape_string($media_url_db)."','".$conn->real_escape_string($media_filename_db)."','".$conn->real_escape_string($wamid)."','delivered',NOW())";
$conn->query($sql);
http_response_code(200);