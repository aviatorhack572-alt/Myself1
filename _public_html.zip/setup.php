<?php
require_once "config.php"; // آپ کی ڈیٹا بیس کنکشن فائل

// 1. phone_numbers ٹیبل چیک اور کریٹ کریں
$sql_phone_numbers = "CREATE TABLE IF NOT EXISTS `phone_numbers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `phone_id` VARCHAR(50) NOT NULL UNIQUE,
  `display_phone_number` VARCHAR(50) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql_phone_numbers) === TRUE) {
    echo "<p style='color: green;'>✓ 'phone_numbers' table is ready.</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating phone_numbers table: " . $conn->error . "</p>";
}

// 2. messages ٹیبل چیک اور کریٹ کریں
$sql_messages = "CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `phone_number_id` INT NOT NULL,
  `wa_id` VARCHAR(50) NOT NULL,
  `message_body` TEXT DEFAULT NULL,
  `message_type` VARCHAR(50) DEFAULT 'text',
  `media_url` VARCHAR(255) DEFAULT NULL,
  `direction` ENUM('incoming', 'outgoing') NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($conn->query($sql_messages) === TRUE) {
    echo "<p style='color: green;'>✓ 'messages' table is ready.</p>";
} else {
    echo "<p style='color: red;'>✗ Error creating messages table: " . $conn->error . "</p>";
}

// 3. اگر آپ کے پاس users کا ٹیبل ہے تو اسے بھی یہاں چیک یا ایڈجسٹ کیا جا سکتا ہے
echo "<h3>Database setup check completed successfully!</h3>";
echo "<p>اب آپ اپنے ڈیش بورڈ اور ویب ہک کو بغیر کسی پریشانی کے استعمال کر سکتے ہیں۔</p>";
?>