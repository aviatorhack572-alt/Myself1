<?php
/**
 * One-time database table installer for this website.
 * Upload beside config.php, open it once, then DELETE this file.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['confirm_install']) || $_POST['confirm_install'] !== 'CREATE_MY_TABLES') {
    ?><!doctype html><html lang="ur"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Database Installer</title></head><body style="font-family:Arial,sans-serif;max-width:650px;margin:40px auto;padding:20px;line-height:1.7"><h2>Database Table Installer</h2><p>یہ فائل آپ کی <code>config.php</code> میں موجود کنکشن استعمال کرکے ضروری ٹیبلز بنائے گی۔ یہ موجودہ ٹیبلز یا ان کے ڈیٹا کو حذف نہیں کرے گی۔</p><p><strong>ضروری:</strong> Hostinger hPanel میں MySQL ڈیٹابیس پہلے سے بنائیں اور <code>config.php</code> میں اس کی درست تفصیلات رکھیں۔</p><form method="post"><button style="padding:12px 18px;font-size:16px" name="confirm_install" value="CREATE_MY_TABLES">ٹیبلز بنائیں</button></form><p>انسٹالیشن مکمل ہونے کے فوراً بعد <code>install.php</code> سرور سے حذف کر دیں۔</p></body></html><?php
    exit;
}

header('Content-Type: text/html; charset=utf-8');
function out($s) { echo htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

if (!is_file(__DIR__ . '/config.php')) {
    http_response_code(500); exit('Error: config.php فائل اسی فولڈر میں نہیں ملی۔');
}
require_once __DIR__ . '/config.php';
if (!isset($conn) || !($conn instanceof mysqli) || $conn->connect_error) {
    http_response_code(500); exit('Database connection failed. config.php اور Hostinger MySQL تفصیلات چیک کریں۔');
}
$conn->set_charset('utf8mb4');

$tables = [
    'phone_numbers' => "CREATE TABLE IF NOT EXISTS `phone_numbers` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_id` INT UNSIGNED DEFAULT NULL,
        `phone_number` VARCHAR(32) NOT NULL,
        `phone_id` VARCHAR(100) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_phone_id` (`phone_id`),
        KEY `idx_phone_number` (`phone_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'users' => "CREATE TABLE IF NOT EXISTS `users` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `username` VARCHAR(100) NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `phone_number_id` INT UNSIGNED NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_users_username` (`username`),
        KEY `idx_users_phone_number_id` (`phone_number_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'messages' => "CREATE TABLE IF NOT EXISTS `messages` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `phone_number_id` INT UNSIGNED NOT NULL,
        `sender_phone` VARCHAR(32) NOT NULL,
        `message_body` TEXT DEFAULT NULL,
        `msg_type` VARCHAR(40) NOT NULL DEFAULT 'text',
        `media_url` VARCHAR(500) DEFAULT NULL,
        `direction` VARCHAR(20) NOT NULL DEFAULT 'inbound',
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_messages_conversation` (`phone_number_id`, `sender_phone`, `id`),
        KEY `idx_messages_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
    'admins' => "CREATE TABLE IF NOT EXISTS `admins` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `username` VARCHAR(100) NOT NULL,
        `password` VARCHAR(255) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uq_admins_username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

$errors = [];
echo '<!doctype html><html lang="ur"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install Result</title><body style="font-family:Arial,sans-serif;max-width:700px;margin:40px auto;padding:20px;line-height:1.8"><h2>Database Installer Result</h2><ul>';
foreach ($tables as $name => $sql) {
    if ($conn->query($sql)) {
        echo '<li> کامیاب: <code>'; out($name); echo '</code> ٹیبل تیار ہے۔</li>';
    } else {
        $errors[] = $name . ': ' . $conn->error;
        echo '<li style="color:#b91c1c">ناکام: <code>'; out($name); echo '</code> — '; out($conn->error); echo '</li>';
    }
}
echo '</ul>';
if ($errors) echo '<p style="color:#b91c1c">کچھ ٹیبلز نہیں بن سکیں۔ اوپر دیا گیا ایرر Hostinger کے MySQL permissions یا SQL سیٹنگز کے لیے چیک کریں۔</p>';
else echo '<p style="color:green">تمام مطلوبہ ٹیبلز بن گئے یا پہلے سے موجود تھے۔</p>';
echo '<p><strong>اب install.php کو فوراً سرور سے حذف کر دیں۔</strong></p><p>نوٹ: ٹیبلز بننے سے پرانے یوزرز، ایڈمن اکاؤنٹس یا پیغامات واپس نہیں آتے۔ ایڈمن ٹیبل خالی ہے؛ لاگ اِن کے لیے ایڈمن اکاؤنٹ الگ سے بنانا ہوگا۔</p></body></html>';
?>
