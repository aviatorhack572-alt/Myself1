<?php
session_start();
require_once "../config.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        // Admins table se username check karna (plain text password comparison)
        $stmt = $conn->prepare("SELECT id, username, password FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            
            // Plain text password match check
            if ($password === $row['password']) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $row['id'];
                $_SESSION['admin_username'] = $row['username'];
                
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Ghalat password darj kiya gaya hai.";
            }
        } else {
            $error = "Yeh admin username mojood nahi hai.";
        }
        $stmt->close();
    } else {
        $error = "Tamam fields pur karna lazmi hain.";
    }
}
?>
<!DOCTYPE html>
<html lang="ur" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - myrealearning.com</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f0f2f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .wa-header-bg {
            background-color: #075e54;
        }
        .wa-btn {
            background-color: #128c7e;
            transition: background-color 0.3s ease;
        }
        .wa-btn:hover {
            background-color: #0d6d63;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen">

    <!-- Top Strip -->
    <div class="wa-header-bg h-32 w-full absolute top-0 left-0 z-0"></div>

    <!-- Main Container -->
    <div class="flex flex-col items-center justify-center flex-grow z-10 px-4 mt-12">
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-8 border-t-4 border-[#075e54]">
            
            <!-- Icon -->
            <div class="w-16 h-16 bg-[#075e54] rounded-full flex items-center justify-center mx-auto mb-4 shadow-md text-white text-2xl">
                <i class="fa-solid fa-user-shield"></i>
            </div>

            <!-- Heading -->
            <h1 class="text-2xl font-bold text-gray-800 text-center mb-2">Admin Login</h1>
            <p class="text-gray-500 text-sm text-center mb-6">Apna admin username aur password darj karein</p>

            <!-- Error Message -->
            <?php if (!empty($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4 text-sm text-center">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Form -->
            <form action="" method="POST">
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Admin Username</label>
                    <input type="text" name="username" required placeholder="Misal: admin" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#075e54]">
                </div>

                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Password</label>
                    <input type="password" name="password" required placeholder="Password likhein" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-[#075e54]">
                </div>

                <button type="submit" class="wa-btn text-white font-semibold py-3 px-4 rounded-lg shadow-md w-full text-center text-lg">
                    Login Karein
                </button>
            </form>

            <!-- Back Link -->
            <div class="text-center mt-6">
                <a href="../index.php" class="text-sm text-[#075e54] hover:underline">
                    <i class="fa-solid fa-arrow-left mr-1"></i> Wapas Home Page par jayein
                </a>
            </div>

        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center py-4 text-gray-500 text-sm z-10">
        &copy; 2026 myrealearning.com - Jumla huquq mehfooz hain.
    </footer>

</body>
</html>