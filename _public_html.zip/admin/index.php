<?php
session_start();

// اگر ایڈمن پہلے سے لاگ ان ہے تو ڈیش بورڈ پر بھیجیں، ورنہ لاگ ان پیج پر ری ڈائریکٹ کریں
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: dashboard.php");
    exit();
} else {
    header("Location: login.php");
    exit();
}
?>