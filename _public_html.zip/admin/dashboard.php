
<?php
session_start();
require_once "../config.php";

// Testing کے بعد false ہی رکھنا بہتر ہے۔
$DEBUG = false;

if ($DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

if (!isset($conn) || !($conn instanceof mysqli) || $conn->connect_error) {
    http_response_code(500);
    exit("Database connection failed.");
}

$conn->set_charset("utf8mb4");

// Admin login required
if (($_SESSION['admin_logged_in'] ?? false) !== true) {
    header("Location: login.php");
    exit;
}

function admin_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function admin_table_exists($conn, $table) {
    $stmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM information_schema.tables
        WHERE table_schema = DATABASE() AND table_name = ?
    ");

    if (!$stmt) return false;

    $stmt->bind_param("s", $table);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row && (int)$row['total'] > 0;
}

function admin_count($conn, $table) {
    // Only fixed internal table names are passed to this function.
    if (!admin_table_exists($conn, $table)) return 0;

    $allowed = ['users', 'phone_numbers', 'messages'];
    if (!in_array($table, $allowed, true)) return 0;

    $result = $conn->query("SELECT COUNT(*) AS total FROM `$table`");
    if (!$result) return 0;

    $row = $result->fetch_assoc();
    return (int)($row['total'] ?? 0);
}

$total_users = admin_count($conn, 'users');
$total_numbers = admin_count($conn, 'phone_numbers');
$total_messages = admin_count($conn, 'messages');

$admin_name = $_SESSION['admin_username'] ?? 'Admin';
?>
<!DOCTYPE html>
<html lang="ur" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Dashboard | WhatsApp CRM</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #f4f7f6;
            font-family: Tahoma, Arial, sans-serif;
        }
        .brand { background: #075e54; }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 15px;
            border-radius: 9px;
            color: #374151;
            transition: .2s;
        }
        .sidebar-link:hover {
            background: #e6f4ef;
            color: #075e54;
        }
        .stat-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 15px;
            padding: 22px;
        }
    </style>
</head>
<body class="min-h-screen">

<header class="brand sticky top-0 z-20 flex items-center justify-between px-4 py-4 text-white shadow md:px-7">
    <div class="flex items-center gap-3">
        <div class="flex h-10 w-10 items-center justify-center rounded-full bg-white/15">
            <i class="fa-brands fa-whatsapp text-2xl"></i>
        </div>
        <div>
            <h1 class="text-lg font-bold">WhatsApp CRM</h1>
            <p class="text-xs text-green-100">Admin Panel</p>
        </div>
    </div>

    <a href="logout.php"
       class="rounded-lg bg-white/10 px-3 py-2 text-sm hover:bg-white/20">
        <i class="fa-solid fa-right-from-bracket ml-1"></i>
        لاگ آؤٹ
    </a>
</header>

<div class="mx-auto flex max-w-7xl flex-col gap-5 p-4 md:flex-row md:p-6">

    <aside class="h-fit w-full flex-shrink-0 rounded-2xl border border-gray-200 bg-white p-3 md:w-64">
        <div class="mb-4 rounded-xl bg-gray-50 p-4">
            <div class="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-green-100 text-xl text-green-800">
                <i class="fa-solid fa-user-shield"></i>
            </div>
            <p class="text-xs text-gray-500">خوش آمدید</p>
            <h2 class="mt-1 break-words font-bold text-gray-800">
                <?php echo admin_h($admin_name); ?>
            </h2>
        </div>

        <nav class="space-y-1">
            <a href="dashboard.php" class="sidebar-link bg-green-50 font-semibold text-green-800">
                <i class="fa-solid fa-gauge-high w-5"></i>
                ڈیش بورڈ
            </a>

            <a href="manage_users.php" class="sidebar-link">
                <i class="fa-solid fa-users w-5"></i>
                صارفین مینج کریں
            </a>

            <a href="add_user.php" class="sidebar-link">
                <i class="fa-solid fa-user-plus w-5"></i>
                نیا صارف شامل کریں
            </a>

            <a href="menu_flows.php" class="sidebar-link">
                <i class="fa-solid fa-diagram-project w-5"></i>
                آٹو میسج مینو
            </a>

            <a href="../user/login.php" target="_blank" rel="noopener" class="sidebar-link">
                <i class="fa-solid fa-comments w-5"></i>
                یوزر پورٹل
            </a>

            <div class="my-3 border-t border-gray-100"></div>

            <a href="logout.php" class="sidebar-link text-red-600 hover:bg-red-50 hover:text-red-700">
                <i class="fa-solid fa-right-from-bracket w-5"></i>
                لاگ آؤٹ
            </a>
        </nav>
    </aside>

    <main class="min-w-0 flex-1">
        <div class="mb-6">
            <p class="mb-1 text-sm text-gray-500">Admin Control Panel</p>
            <h2 class="text-2xl font-bold text-gray-900">ایڈمن ڈیش بورڈ</h2>
            <p class="mt-2 text-sm text-gray-600">
                یہاں سے صارفین، WhatsApp نمبرز اور خودکار جوابات کا انتظام کریں۔
            </p>
        </div>

        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">

            <div class="stat-card">
                <div class="mb-5 flex items-center justify-between">
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-blue-700">
                        <i class="fa-solid fa-users text-xl"></i>
                    </div>
                    <span class="text-xs text-gray-500">کل صارفین</span>
                </div>
                <div class="text-3xl font-bold text-gray-900">
                    <?php echo $total_users; ?>
                </div>
                <a href="manage_users.php" class="mt-4 inline-block text-sm font-semibold text-blue-700 hover:underline">
                    صارفین دیکھیں <i class="fa-solid fa-arrow-left mr-1"></i>
                </a>
            </div>

            <div class="stat-card">
                <div class="mb-5 flex items-center justify-between">
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-green-50 text-green-700">
                        <i class="fa-brands fa-whatsapp text-2xl"></i>
                    </div>
                    <span class="text-xs text-gray-500">منسلک نمبر</span>
                </div>
                <div class="text-3xl font-bold text-gray-900">
                    <?php echo $total_numbers; ?>
                </div>
                <a href="manage_users.php" class="mt-4 inline-block text-sm font-semibold text-green-700 hover:underline">
                    نمبرز مینج کریں <i class="fa-solid fa-arrow-left mr-1"></i>
                </a>
            </div>

            <div class="stat-card">
                <div class="mb-5 flex items-center justify-between">
                    <div class="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-50 text-purple-700">
                        <i class="fa-solid fa-message text-xl"></i>
                    </div>
                    <span class="text-xs text-gray-500">محفوظ پیغامات</span>
                </div>
                <div class="text-3xl font-bold text-gray-900">
                    <?php echo $total_messages; ?>
                </div>
                <p class="mt-4 text-sm text-gray-500">
                    ڈیٹابیس میں موجود پیغامات
                </p>
            </div>

        </div>

        <section class="mt-6 rounded-2xl border border-gray-200 bg-white p-5 md:p-6">
            <h3 class="mb-2 text-lg font-bold text-gray-900">
                <i class="fa-solid fa-bolt ml-2 text-green-700"></i>
                فوری کام
            </h3>
            <p class="mb-5 text-sm text-gray-600">
                مطلوبہ انتظامی حصے میں جانے کے لیے کوئی آپشن منتخب کریں۔
            </p>

            <div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <a href="add_user.php"
                   class="flex items-center gap-3 rounded-xl border border-gray-200 p-4 hover:border-green-400 hover:bg-green-50">
                    <i class="fa-solid fa-user-plus text-xl text-green-700"></i>
                    <div>
                        <div class="font-bold text-gray-800">نیا صارف</div>
                        <div class="mt-1 text-xs text-gray-500">نمبر اور لاگ اِن تفصیلات شامل کریں</div>
                    </div>
                </a>

                <a href="manage_users.php"
                   class="flex items-center gap-3 rounded-xl border border-gray-200 p-4 hover:border-green-400 hover:bg-green-50">
                    <i class="fa-solid fa-users-gear text-xl text-green-700"></i>
                    <div>
                        <div class="font-bold text-gray-800">صارفین اور نمبرز</div>
                        <div class="mt-1 text-xs text-gray-500">موجودہ صارفین کا انتظام کریں</div>
                    </div>
                </a>

                <a href="menu_flows.php"
                   class="flex items-center gap-3 rounded-xl border border-gray-200 p-4 hover:border-green-400 hover:bg-green-50 sm:col-span-2">
                    <i class="fa-solid fa-diagram-project text-xl text-green-700"></i>
                    <div>
                        <div class="font-bold text-gray-800">آٹو میسج اور مینو سیٹنگز</div>
                        <div class="mt-1 text-xs text-gray-500">ہر WhatsApp نمبر کے لیے الگ ویلکم میسج، مینو اور جوابات</div>
                    </div>
                </a>
            </div>
        </section>

        <p class="mt-5 text-center text-xs text-gray-500">
            WhatsApp CRM Admin Panel
        </p>
    </main>
</div>

</body>
</html>
