
<?php
session_start();
require_once "../config.php";

// Admin login check
if (
    !isset($_SESSION["admin_logged_in"]) ||
    $_SESSION["admin_logged_in"] !== true
) {
    header("Location: login.php");
    exit;
}

// Optional PHP error reporting: change true to false when finished testing.
$SHOW_ERRORS = true;

if ($SHOW_ERRORS) {
    ini_set("display_errors", "1");
    ini_set("display_startup_errors", "1");
    error_reporting(E_ALL);
} else {
    ini_set("display_errors", "0");
    error_reporting(0);
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$message = "";
$messageType = "success";

// CSRF token
if (empty($_SESSION["add_user_csrf"])) {
    $_SESSION["add_user_csrf"] = bin2hex(random_bytes(32));
}

function addUserTableExists(mysqli $conn, string $table): bool
{
    $stmt = $conn->prepare(
        "SELECT COUNT(*) FROM information_schema.tables
         WHERE table_schema = DATABASE() AND table_name = ?"
    );
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    return (int)$count > 0;
}

try {
    // Create tables only if they do not already exist.
    if (!addUserTableExists($conn, "phone_numbers")) {
        $conn->query("
            CREATE TABLE phone_numbers (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                phone_number VARCHAR(30) NOT NULL,
                phone_id VARCHAR(150) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    if (!addUserTableExists($conn, "users")) {
        $conn->query("
            CREATE TABLE users (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(100) NOT NULL,
                password VARCHAR(255) NOT NULL,
                phone_number_id BIGINT UNSIGNED NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }
} catch (Throwable $e) {
    error_log("Add user setup error: " . $e->getMessage());
    $message = "Database setup mein masla hai. Tables aur columns check karein.";
    $messageType = "error";
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && $message === "") {
    $csrf = $_POST["csrf_token"] ?? "";

    if (
        !is_string($csrf) ||
        !hash_equals($_SESSION["add_user_csrf"], $csrf)
    ) {
        $message = "Session verification fail ho gayi. Page refresh karke dobara try karein.";
        $messageType = "error";
    } else {
        $phoneNumber = trim($_POST["phone_number"] ?? "");
        $phoneId = trim($_POST["phone_id"] ?? "");
        $username = trim($_POST["username"] ?? "");
        $password = $_POST["password"] ?? "";

        if (
            $phoneNumber === "" ||
            $phoneId === "" ||
            $username === "" ||
            $password === ""
        ) {
            $message = "Tamam fields bharna zaroori hai.";
            $messageType = "error";
        } elseif (
            strlen($phoneNumber) > 30 ||
            strlen($phoneId) > 150 ||
            strlen($username) > 100 ||
            strlen($password) < 8 ||
            strlen($password) > 4096
        ) {
            $message = "Kisi field ki length ghalat hai. Password kam az kam 8 characters ka rakhein.";
            $messageType = "error";
        } else {
            try {
                $conn->begin_transaction();

                // Check duplicate username.
                $stmt = $conn->prepare(
                    "SELECT id FROM users WHERE username = ? LIMIT 1"
                );
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $stmt->store_result();
                $usernameExists = $stmt->num_rows > 0;
                $stmt->close();

                // Check duplicate business phone number or Meta Phone Number ID.
                $stmt = $conn->prepare(
                    "SELECT id FROM phone_numbers
                     WHERE phone_number = ? OR phone_id = ?
                     LIMIT 1"
                );
                $stmt->bind_param("ss", $phoneNumber, $phoneId);
                $stmt->execute();
                $stmt->store_result();
                $numberExists = $stmt->num_rows > 0;
                $stmt->close();

                if ($usernameExists) {
                    $conn->rollback();
                    $message = "Yeh username pehle se mojood hai.";
                    $messageType = "error";
                } elseif ($numberExists) {
                    $conn->rollback();
                    $message = "Yeh WhatsApp number ya Meta Phone Number ID pehle se linked hai.";
                    $messageType = "error";
                } else {
                    $hashedPassword = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    if ($hashedPassword === false) {
                        throw new RuntimeException("Password hashing failed.");
                    }

                    // Save the business WhatsApp number.
                    $stmt = $conn->prepare(
                        "INSERT INTO phone_numbers (phone_number, phone_id)
                         VALUES (?, ?)"
                    );
                    $stmt->bind_param("ss", $phoneNumber, $phoneId);
                    $stmt->execute();
                    $localPhoneNumberId = $conn->insert_id;
                    $stmt->close();

                    // Link the new user to that local phone number record.
                    $stmt = $conn->prepare(
                        "INSERT INTO users (username, password, phone_number_id)
                         VALUES (?, ?, ?)"
                    );
                    $stmt->bind_param(
                        "ssi",
                        $username,
                        $hashedPassword,
                        $localPhoneNumberId
                    );
                    $stmt->execute();
                    $stmt->close();

                    $conn->commit();

                    // Refresh CSRF token after successful submission.
                    $_SESSION["add_user_csrf"] = bin2hex(random_bytes(32));

                    $message = "User successfully add ho gaya!";
                    $messageType = "success";
                }
            } catch (Throwable $e) {
                try {
                    $conn->rollback();
                } catch (Throwable $ignored) {
                }

                error_log("Add user error: " . $e->getMessage());
                $message = "User add nahi ho saka. Database columns aur data types check karein.";
                $messageType = "error";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User | Admin Panel</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f3f6fb;
            color: #1e293b;
        }
        .topbar {
            background: #075e54;
            color: #fff;
            padding: 18px 24px;
            font-size: 21px;
            font-weight: bold;
        }
        .container {
            width: min(700px, 94%);
            margin: 30px auto;
        }
        .back {
            display: inline-block;
            margin-bottom: 18px;
            color: #075e54;
            text-decoration: none;
            font-weight: bold;
        }
        .card {
            background: #fff;
            padding: 28px;
            border-radius: 14px;
            box-shadow: 0 5px 22px rgba(0,0,0,.06);
        }
        h2 { margin-top: 0; }
        .hint {
            color: #64748b;
            font-size: 13px;
            line-height: 1.6;
        }
        label {
            display: block;
            font-weight: bold;
            margin: 18px 0 7px;
        }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            font-size: 15px;
        }
        input:focus {
            outline: 2px solid #a7d8d0;
            border-color: #075e54;
        }
        button {
            width: 100%;
            margin-top: 24px;
            padding: 13px;
            background: #075e54;
            color: white;
            border: 0;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover { background: #064e46; }
        .alert {
            padding: 13px;
            margin-bottom: 18px;
            border-radius: 8px;
            line-height: 1.5;
        }
        .success { background: #dcfce7; color: #166534; }
        .error { background: #fee2e2; color: #991b1b; }
        @media (max-width: 500px) {
            .card { padding: 20px; }
            .topbar { padding: 16px; }
        }
    </style>
</head>
<body>
    <div class="topbar">WhatsApp CRM — Admin Panel</div>

    <div class="container">
        <a class="back" href="dashboard.php">&larr; Back to Dashboard</a>

        <div class="card">
            <h2>Add New User</h2>
            <p class="hint">
                Har user ke saath uska apna WhatsApp business number link hoga.
                Meta Phone Number ID, WhatsApp number se alag field hai.
            </p>

            <?php if ($message !== ""): ?>
                <div class="alert <?= $messageType === "success" ? "success" : "error" ?>">
                    <?= htmlspecialchars($message, ENT_QUOTES, "UTF-8") ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION["add_user_csrf"], ENT_QUOTES, "UTF-8") ?>"
                >

                <label for="phone_number">WhatsApp Business Number</label>
                <input
                    type="text"
                    id="phone_number"
                    name="phone_number"
                    placeholder="e.g. +491234567890"
                    maxlength="30"
                    required
                >

                <label for="phone_id">Meta Phone Number ID</label>
                <input
                    type="text"
                    id="phone_id"
                    name="phone_id"
                    placeholder="Enter Meta Phone Number ID"
                    maxlength="150"
                    required
                >

                <label for="username">User Login Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    maxlength="100"
                    autocomplete="username"
                    required
                >

                <label for="password">User Login Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    minlength="8"
                    maxlength="4096"
                    autocomplete="new-password"
                    required
                >
                <p class="hint">Password kam az kam 8 characters ka hona chahiye.</p>

                <button type="submit">Create User</button>
            </form>
        </div>
    </div>
</body>
</html>
