<?php
session_start();
require_once __DIR__ . '/../config.php';
if (($_SESSION['admin_logged_in'] ?? false) !== true) { header("Location: login.php"); exit; }
$conn->set_charset("utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS auto_bots (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, welcome_message TEXT, is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_phone (phone_number_id))");
$conn->query("CREATE TABLE IF NOT EXISTS auto_menus (id INT AUTO_INCREMENT PRIMARY KEY, phone_number_id INT NOT NULL, parent_id INT NULL, title VARCHAR(190) NOT NULL, button_id VARCHAR(100) NOT NULL, reply_text TEXT NULL, sort_order INT DEFAULT 0, is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$phones = $conn->query("SELECT id, phone_number FROM phone_numbers ORDER BY id DESC");
$all_phones=[]; while($r=$phones->fetch_assoc()) $all_phones[]=$r;
$selected_id = (int)($_GET['phone_number_id'] ?? ($_POST['phone_number_id'] ?? 0));
if($selected_id==0 && $all_phones) $selected_id = (int)$all_phones[0]['id'];
$msg=''; $msg_type=''; $show_import = isset($_GET['import']);

if($_SERVER['REQUEST_METHOD']=='POST'){
  $act=$_POST['act']??'';
  if($act=='import_json'){
    $json_str = trim($_POST['json_data'] ?? '');
    if(isset($_FILES['json_file']) && $_FILES['json_file']['size']>0) $json_str = file_get_contents($_FILES['json_file']['tmp_name']);
    try{
      $data = json_decode($json_str, true); if(!$data) throw new Exception("Invalid JSON");
      $menus = $data['menus'] ?? $data;
      $conn->query("DELETE FROM auto_menus WHERE phone_number_id=$selected_id");
      $welcome = "Assalam-o-Alaikum! FastSky me khush aamdeed.";
      $stmt=$conn->prepare("INSERT INTO auto_bots (phone_number_id, welcome_message, is_active) VALUES (?,?,1) ON DUPLICATE KEY UPDATE welcome_message=VALUES(welcome_message)");
      $stmt->bind_param("is",$selected_id,$welcome); $stmt->execute(); $stmt->close();
      $idMap=[]; usort($menus, fn($a,$b)=>($a['sort_order']??0) <=> ($b['sort_order']??0));
      foreach($menus as $row){ if(($row['menu_type']??'')=='menu' && empty($row['parent_id'])){ $bid='main_'.time().rand(1000,9999).$row['id']; $stmt=$conn->prepare("INSERT INTO auto_menus (phone_number_id, parent_id, title, button_id, reply_text, sort_order, is_active) VALUES (?,NULL,?,?,?,?,?)"); $stmt->bind_param("issiii",$selected_id,$row['title'],$bid,$row['response_text'],$row['sort_order'],$row['is_active']); $stmt->execute(); $idMap[$row['id']]=$conn->insert_id; $stmt->close(); } }
      foreach($menus as $row){ if(($row['menu_type']??'')=='reply'){ $op=(int)($row['parent_id']??0); if(!isset($idMap[$op])) continue; $np=$idMap[$op]; $bid='sub_'.time().rand(1000,9999).$row['id']; $stmt=$conn->prepare("INSERT INTO auto_menus (phone_number_id, parent_id, title, button_id, reply_text, sort_order, is_active) VALUES (?,?,?,?,?,?,?)"); $stmt->bind_param("iisssii",$selected_id,$np,$row['title'],$bid,$row['response_text'],$row['sort_order'],$row['is_active']); $stmt->execute(); $stmt->close(); } }
      $msg="Import Success!"; $msg_type='success';
    }catch(Throwable $e){ $msg="Error: ".$e->getMessage(); $msg_type='error'; }
  }
  if($act=='save_welcome'){ $wm=trim($_POST['welcome_message']??''); $ac=isset($_POST['is_active'])?1:0; $stmt=$conn->prepare("INSERT INTO auto_bots (phone_number_id, welcome_message, is_active) VALUES (?,?,?) ON DUPLICATE KEY UPDATE welcome_message=VALUES(welcome_message), is_active=VALUES(is_active)"); $stmt->bind_param("isi",$selected_id,$wm,$ac); $stmt->execute(); $stmt->close(); header("Location: menu_flows.php?phone_number_id=$selected_id"); exit; }
  if($act=='add_main'){ $t=trim($_POST['title']??''); $o=(int)($_POST['sort_order']??0); if($t){ $bid='main_'.time().rand(100,999); $rt=''; $ac=1; $stmt=$conn->prepare("INSERT INTO auto_menus (phone_number_id, parent_id, title, button_id, reply_text, sort_order, is_active) VALUES (?,NULL,?,?,?,?,?)"); $stmt->bind_param("issii",$selected_id,$t,$bid,$rt,$o,$ac); $stmt->execute(); $stmt->close(); } header("Location: menu_flows.php?phone_number_id=$selected_id"); exit; }
  if($act=='add_sub'){ $t=trim($_POST['title']??''); $rt=trim($_POST['reply_text']??''); $pid=(int)($_POST['parent_id']??0); $o=(int)($_POST['sort_order']??0); if($t && $pid){ $bid='sub_'.time().rand(100,999); $ac=1; $stmt=$conn->prepare("INSERT INTO auto_menus (phone_number_id, parent_id, title, button_id, reply_text, sort_order, is_active) VALUES (?,?,?,?,?,?,?)"); $stmt->bind_param("iisssii",$selected_id,$pid,$t,$bid,$rt,$o,$ac); $stmt->execute(); $stmt->close(); } header("Location: menu_flows.php?phone_number_id=$selected_id"); exit; }
  if($act=='edit_menu'){ $mid=(int)($_POST['menu_id']??0); $t=trim($_POST['title']??''); $rt=trim($_POST['reply_text']??''); $o=(int)($_POST['sort_order']??0); $ac=isset($_POST['is_active'])?1:0; $stmt=$conn->prepare("UPDATE auto_menus SET title=?, reply_text=?, sort_order=?, is_active=? WHERE id=? AND phone_number_id=?"); $stmt->bind_param("ssiiii",$t,$rt,$o,$ac,$mid,$selected_id); $stmt->execute(); $stmt->close(); header("Location: menu_flows.php?phone_number_id=$selected_id"); exit; }
  if($act=='delete_menu'){ $mid=(int)($_POST['menu_id']??0); $conn->query("DELETE FROM auto_menus WHERE id=$mid OR parent_id=$mid"); header("Location: menu_flows.php?phone_number_id=$selected_id"); exit; }
}

$bot=null; $mains=[];
if($selected_id){ $r=$conn->query("SELECT * FROM auto_bots WHERE phone_number_id=$selected_id LIMIT 1"); $bot=$r?$r->fetch_assoc():null; $r2=$conn->query("SELECT * FROM auto_menus WHERE phone_number_id=$selected_id AND parent_id IS NULL ORDER BY sort_order ASC, id ASC"); while($r2 && $row=$r2->fetch_assoc()) $mains[]=$row; }
function getSubs($conn,$pid,$phone){ $subs=[]; $q=$conn->query("SELECT * FROM auto_menus WHERE phone_number_id=$phone AND parent_id=$pid ORDER BY sort_order ASC, id ASC"); while($q && $rw=$q->fetch_assoc()) $subs[]=$rw; return $subs; }
?>
<!DOCTYPE html><html lang="ur" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Auto Bot Menu</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><style>body{background:#f4f7f6;font-family:Tahoma,Arial}.brand{background:#075e54}</style></head><body>
<header class="brand sticky top-0 z-20 flex items-center justify-between px-4 py-4 text-white shadow"><div class="flex items-center gap-3"><i class="fa-brands fa-whatsapp text-2xl"></i><b>Auto Bot - Number Wise</b></div><div class="flex gap-2"><a href="menu_flows.php?phone_number_id=<?=$selected_id?>&import=1" class="bg-yellow-500 text-black px-3 py-2 rounded-lg text-xs font-bold"><i class="fa-solid fa-file-import"></i> Import</a><a href="dashboard.php" class="bg-white/10 px-3 py-2 rounded text-sm">Back</a></div></header>
<div class="mx-auto max-w-7xl p-4">
<?php if($msg):?><div class="mb-4 p-3 rounded-lg <?= $msg_type=='success'?'bg-green-100 text-green-800':'bg-red-100 text-red-800'?>"><?=h($msg)?></div><?php endif; ?>
<form method="get" class="mb-4 bg-white p-4 rounded-xl border flex gap-3"><select name="phone_number_id" class="flex-1 border rounded-lg p-3"><?php foreach($all_phones as $p){ echo '<option value="'.$p['id'].'" '.($p['id']==$selected_id?'selected':'').'>'.h($p['phone_number']).'</option>'; } ?></select><button class="bg-green-700 text-white px-5 rounded-lg font-bold">Load</button></form>

<?php if($show_import): ?><div class="bg-white rounded-2xl border p-5 mb-5"><h3 class="font-bold mb-2">📥 JSON Import</h3><form method="post" enctype="multipart/form-data"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="import_json"><textarea name="json_data" rows="6" class="w-full border rounded-xl p-3 text-xs"></textarea><div class="flex gap-3 mt-3"><input type="file" name="json_file" class="flex-1 border rounded p-2 text-sm"><button class="bg-yellow-600 text-white px-6 py-2.5 rounded-lg font-bold">Import Now</button><a href="menu_flows.php?phone_number_id=<?=$selected_id?>" class="px-4 py-2.5 border rounded-lg">Cancel</a></div></form></div><?php endif; ?>

<?php if($selected_id): ?>
<div class="grid md:grid-cols-3 gap-5">
<div class="space-y-5">
<div class="bg-white rounded-2xl border p-5"><h3 class="font-bold mb-3">👋 Welcome Message</h3><form method="post"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="save_welcome"><textarea name="welcome_message" rows="4" class="w-full border rounded-xl p-3 text-sm"><?=h($bot['welcome_message'] ?? 'Assalam-o-Alaikum! FastSky me khush aamdeed.')?></textarea><label class="flex gap-2 mt-2 text-sm"><input type="checkbox" name="is_active" <?=($bot['is_active']??1)?'checked':''?>> Bot Active</label><button class="mt-3 w-full bg-green-700 text-white rounded-xl py-3 font-bold">Save Welcome</button></form></div>
<div class="bg-white rounded-2xl border p-5"><h3 class="font-bold mb-3">➕ New Main Menu Add</h3><form method="post"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="add_main"><input name="title" required placeholder="Jaise: GAME INFORMATION" class="w-full border rounded-lg p-3 mb-2 text-sm"><input name="sort_order" type="number" placeholder="Tarteeb 1,2,3" value="<?=count($mains)+1?>" class="w-full border rounded-lg p-3 mb-2 text-sm"><button class="w-full bg-green-600 text-white rounded-lg py-2.5 font-bold">Add Main Menu</button></form></div>
</div>
<div class="md:col-span-2 space-y-4">
<?php foreach($mains as $main): $subs=getSubs($conn,$main['id'],$selected_id); ?>
<div class="bg-white rounded-2xl border p-4">
<div class="flex justify-between items-start gap-2"><div><div class="font-bold text-green-800">📁 <?=h($main['title'])?> <span class="text-xs text-gray-400">#<?=$main['id']?> | Order: <?=$main['sort_order']?></span></div><span class="text-xs px-2 py-1 rounded <?= $main['is_active']?'bg-green-100 text-green-700':'bg-red-100 text-red-700'?>"><?= $main['is_active']?'Active':'Off'?></span></div>
<div class="flex gap-1"><button onclick="document.getElementById('edit-<?=$main['id']?>').classList.toggle('hidden')" class="text-xs bg-blue-50 text-blue-700 px-3 py-1.5 rounded-lg"><i class="fa-solid fa-pen"></i> Edit</button><form method="post" onsubmit="return confirm('Delete?')"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="delete_menu"><input type="hidden" name="menu_id" value="<?=$main['id']?>"><button class="text-xs bg-red-50 text-red-600 px-3 py-1.5 rounded-lg">Delete</button></form></div></div>
<div id="edit-<?=$main['id']?>" class="hidden mt-3 p-3 bg-gray-50 rounded-xl border"><form method="post"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="edit_menu"><input type="hidden" name="menu_id" value="<?=$main['id']?>"><input name="title" value="<?=h($main['title'])?>" class="w-full border rounded p-2 mb-2 text-sm"><input name="sort_order" type="number" value="<?=$main['sort_order']?>" class="w-full border rounded p-2 mb-2 text-sm"><label class="flex gap-2 text-xs mb-2"><input type="checkbox" name="is_active" <?= $main['is_active']?'checked':''?>> Active</label><button class="bg-blue-600 text-white px-4 py-2 rounded text-xs">Update</button></form></div>

<div class="mt-4 bg-green-50/50 rounded-xl p-3 border">
<h4 class="text-sm font-bold mb-2">↳ Sub Menus (<?=count($subs)?>)</h4>
<?php foreach($subs as $s): ?>
<div class="bg-white border rounded-lg p-3 mb-2"><div class="flex justify-between"><b class="text-sm"><?=h($s['title'])?></b><div class="flex gap-1"><button onclick="document.getElementById('edit-<?=$s['id']?>').classList.toggle('hidden')" class="text-[11px] bg-blue-50 text-blue-600 px-2 py-1 rounded">Edit</button><form method="post"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="delete_menu"><input type="hidden" name="menu_id" value="<?=$s['id']?>"><button class="text-[11px] bg-red-50 text-red-600 px-2 py-1 rounded">Del</button></form></div></div><div class="text-[11px] text-gray-500 whitespace-pre-wrap mt-1"><?=h(mb_substr($s['reply_text']??'',0,200))?></div>
<div id="edit-<?=$s['id']?>" class="hidden mt-2 p-2 bg-gray-50 rounded border"><form method="post"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="edit_menu"><input type="hidden" name="menu_id" value="<?=$s['id']?>"><input name="title" value="<?=h($s['title'])?>" class="w-full border rounded p-2 mb-2 text-xs"><textarea name="reply_text" rows="4" class="w-full border rounded p-2 mb-2 text-xs"><?=h($s['reply_text'])?></textarea><div class="flex gap-2"><input name="sort_order" type="number" value="<?=$s['sort_order']?>" class="w-20 border rounded p-2 text-xs"><label class="flex gap-1 text-xs items-center"><input type="checkbox" name="is_active" <?= $s['is_active']?'checked':''?>> Active</label><button class="bg-blue-600 text-white px-3 py-1.5 rounded text-xs ml-auto">Update Sub</button></div></form></div>
</div>
<?php endforeach; ?>
<details class="mt-3"><summary class="cursor-pointer text-xs font-bold text-green-700">➕ New Sub Menu Add</summary><form method="post" class="mt-2 bg-white p-3 rounded border"><input type="hidden" name="phone_number_id" value="<?=$selected_id?>"><input type="hidden" name="act" value="add_sub"><input type="hidden" name="parent_id" value="<?=$main['id']?>"><input name="title" required placeholder="Sub Title" class="w-full border rounded p-2 mb-2 text-xs"><textarea name="reply_text" rows="3" placeholder="Jawab / Reply Text" class="w-full border rounded p-2 mb-2 text-xs"></textarea><input name="sort_order" type="number" value="<?=count($subs)+1?>" class="w-full border rounded p-2 mb-2 text-xs"><button class="w-full bg-green-600 text-white rounded py-2 text-xs font-bold">Add Sub Menu</button></form></details>
</div>
</div>
<?php endforeach; if(!count($mains)) echo '<div class="bg-white border rounded-xl p-10 text-center text-gray-400">Koi Main Menu nahi, upar se add karo ya Import se lao</div>'; ?>
</div>
</div>
<?php endif; ?>
</div></body></html>